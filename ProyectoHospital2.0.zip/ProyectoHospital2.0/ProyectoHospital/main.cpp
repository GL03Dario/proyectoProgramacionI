#include "controladores/ControladorDepartamentos.h"
#include "controladores/ControladorEmpleados.h"
#include "controladores/ServicioPlanilla.h"
#include "modelo/FabricaEmpleado.h"
#include "persistencia/AlmacenamientoArchivos.h"
#include "vista/InterfazConsola.h"

#include <exception>
#include <iostream>

int main() {
	try {
		FabricaEmpleado fabrica;
		
		AlmacenamientoArchivos almacenamiento(fabrica);
		
		ControladorDepartamentos controladorDepartamentos(almacenamiento);
		
		ControladorEmpleados controladorEmpleados(almacenamiento, fabrica, controladorDepartamentos);
		
		ServicioPlanilla servicioPlanilla(almacenamiento, controladorEmpleados, controladorDepartamentos);
		
		InterfazConsola interfaz(controladorEmpleados,controladorDepartamentos,servicioPlanilla,fabrica);
		
		interfaz.ejecutar();
	} catch (const std::exception& e) {
		std::cerr << "Error fatal: " << e.what() << "\n";
		return 1;
	}
	
	return 0;
}
