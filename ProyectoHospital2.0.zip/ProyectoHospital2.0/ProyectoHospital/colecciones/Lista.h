#ifndef LISTA_H
#define LISTA_H

#include "colecciones/Nodo.h"
#include <stdexcept>
#include <string>

template <typename T>
class Lista {
private:
	Nodo<T>* cabeza;
	Nodo<T>* cola;
	int tamano;
	
public:
	Lista() : cabeza(nullptr), cola(nullptr), tamano(0) {}
	
	~Lista() { limpiar(); }
	
	Lista(const Lista&) = delete;
	Lista& operator=(const Lista&) = delete;
	
	void agregar(T* elemento) {
		if (elemento == nullptr) {
			throw std::invalid_argument(
										"No se puede agregar un elemento nulo a la lista.");
		}
		
		Nodo<T>* nuevo = new Nodo<T>(elemento);
		
		if (cola == nullptr) {
			cabeza = nuevo;
		} else {
			cola->setSiguiente(nuevo);
		}
		
		cola = nuevo;
		++tamano;
	}
	
	bool eliminar(const T* elemento) {
		Nodo<T>* anterior = nullptr;
		Nodo<T>* actual = cabeza;
		
		while (actual != nullptr) {
			if (actual->getDato() == elemento) {
				Nodo<T>* siguiente = actual->getSiguiente();
				
				if (anterior == nullptr) {
					cabeza = siguiente;
				} else {
					anterior->setSiguiente(siguiente);
				}
				
				if (actual == cola) {
					cola = anterior;
				}
				
				delete actual->getDato();
				delete actual;
				--tamano;
				return true;
			}
			
			anterior = actual;
			actual = actual->getSiguiente();
		}
		
		return false;
	}
	
	T* obtener(int indice) const {
		if (indice < 0 || indice >= tamano) {
			throw std::out_of_range(
									"Indice fuera de rango: " + std::to_string(indice));
		}
		
		Nodo<T>* actual = cabeza;
		
		for (int i = 0; i < indice; ++i) {
			actual = actual->getSiguiente();
		}
		
		return actual->getDato();
	}
	
	Nodo<T>* primero() const { return cabeza; }
	
	int getTamano() const { return tamano; }
	bool estaVacia() const { return tamano == 0; }
	
	void limpiar() {
		Nodo<T>* actual = cabeza;
		
		while (actual != nullptr) {
			Nodo<T>* siguiente = actual->getSiguiente();
			delete actual->getDato();
			delete actual;
			actual = siguiente;
		}
		
		cabeza = nullptr;
		cola = nullptr;
		tamano = 0;
	}
};

#endif
