#ifndef NODO_H
#define NODO_H

template <typename T>
class Nodo {
private:
	T* dato;
	Nodo<T>* siguiente;
	
public:
	explicit Nodo(T* dato) : dato(dato), siguiente(nullptr) {}
	
	Nodo(const Nodo&) = delete;
	Nodo& operator=(const Nodo&) = delete;
	
	T* getDato() const { return dato; }
	Nodo<T>* getSiguiente() const { return siguiente; }
	void setSiguiente(Nodo<T>* nuevoSiguiente) { siguiente = nuevoSiguiente; }
};

#endif
