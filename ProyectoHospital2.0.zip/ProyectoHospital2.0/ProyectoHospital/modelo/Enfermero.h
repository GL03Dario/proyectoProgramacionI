#ifndef ENFERMERO_H
#define ENFERMERO_H

#include "modelo/Empleado.h"
#include <string>

class Enfermero : public Empleado {
	
private:
	std::string areaAsignada;
	double bonificacionArea;
	
public:
	Enfermero(
			  const std::string& identificacion,
			  const std::string& nombre,
			  double salarioBase,
			  double horasExtra,
			  double valorHoraExtra,
			  int turnosNocturnos,
			  double bonificacionTurnoNocturno,
			  int guardias,
			  double bonificacionGuardia,
			  double tasaDeduccionLegal,
			  const std::string& areaAsignada,
			  double bonificacionArea
			  );
	
	std::string obtenerTipo() const override;
	
	std::string obtenerDetallePuesto() const override;
	void setDetallePuesto(const std::string& valor) override;
	
	double calcularBonificacionPuesto() const override;
	void setBonificacionPuesto(double valor) override;
	
	const std::string& getAreaAsignada() const;
	double getBonificacionArea() const;
};

#endif
