#include "modelo/ComprobantePago.h"
#include <stdexcept>

using namespace std;

void ComprobantePago::validarEncabezado(
										int numero,
										const string& periodo,
										const string& fechaEmision) {
	
	if (numero <= 0) {
		throw invalid_argument(
							   "El numero de comprobante debe ser mayor que cero.");
	}
	
	if (periodo.empty()) {
		throw invalid_argument(
							   "El periodo no puede estar vacio.");
	}
	
	if (fechaEmision.empty()) {
		throw invalid_argument(
							   "La fecha de emision no puede estar vacia.");
	}
}

ComprobantePago::ComprobantePago(
								 int numero,
								 const string& periodo,
								 const string& fechaEmision,
								 const Empleado* empleado,
								 const Departamento* departamento)
	
	: numero(numero),
	periodo(periodo),
	fechaEmision(fechaEmision),
	pagado(false),
	fechaPago(),
	empleado(empleado),
	departamento(departamento),
	idEmpleado(),
	nombreEmpleado(),
	tipoEmpleado(),
	codigoDepartamento(),
	nombreDepartamento(),
	desglose() {
	
	validarEncabezado(numero, periodo, fechaEmision);
	
	if (empleado == nullptr) {
		throw invalid_argument(
							   "El comprobante requiere un empleado.");
	}
	
	idEmpleado = empleado->getIdentificacion();
	nombreEmpleado = empleado->getNombre();
	tipoEmpleado = empleado->obtenerTipo();
	
	if (departamento != nullptr) {
		codigoDepartamento = departamento->getCodigo();
		nombreDepartamento = departamento->getNombre();
	}
	
	desglose.salarioBase = empleado->getSalarioBase();
	desglose.pagoHorasExtra = empleado->calcularPagoHorasExtra();
	desglose.bonificacionNocturna = empleado->calcularBonificacionNocturna();
	desglose.bonificacionGuardias = empleado->calcularBonificacionGuardias();
	desglose.bonificacionPuesto = empleado->calcularBonificacionPuesto();
	desglose.salarioBruto = empleado->calcularSalarioBruto();
	desglose.deduccionLegal = empleado->calcularDeduccionLegal();
	desglose.salarioNeto = empleado->calcularSalarioNeto();
}

ComprobantePago::ComprobantePago(
								 int numero,
								 const string& periodo,
								 const string& fechaEmision,
								 bool pagado,
								 const string& fechaPago,
								 const string& idEmpleado,
								 const string& nombreEmpleado,
								 const string& tipoEmpleado,
								 const string& codigoDepartamento,
								 const string& nombreDepartamento,
								 const DesglosePago& desglose,
								 const Empleado* empleado,
								 const Departamento* departamento)
	
	: numero(numero),
	periodo(periodo),
	fechaEmision(fechaEmision),
	pagado(pagado),
	fechaPago(fechaPago),
	empleado(empleado),
	departamento(departamento),
	idEmpleado(idEmpleado),
	nombreEmpleado(nombreEmpleado),
	tipoEmpleado(tipoEmpleado),
	codigoDepartamento(codigoDepartamento),
	nombreDepartamento(nombreDepartamento),
	desglose(desglose) {
	
	validarEncabezado(numero, periodo, fechaEmision);
	
	if (idEmpleado.empty()) {
		throw invalid_argument(
							   "El comprobante debe indicar la identificacion del empleado.");
	}
}

int ComprobantePago::getNumero() const {
	return numero;
}

const string& ComprobantePago::getPeriodo() const {
	return periodo;
}

const string& ComprobantePago::getFechaEmision() const {
	return fechaEmision;
}

bool ComprobantePago::estaPagado() const {
	return pagado;
}

const string& ComprobantePago::getFechaPago() const {
	return fechaPago;
}

const Empleado* ComprobantePago::getEmpleado() const {
	return empleado;
}

const Departamento* ComprobantePago::getDepartamento() const {
	return departamento;
}

const string& ComprobantePago::getIdEmpleado() const {
	return idEmpleado;
}

const string& ComprobantePago::getNombreEmpleado() const {
	return nombreEmpleado;
}

const string& ComprobantePago::getTipoEmpleado() const {
	return tipoEmpleado;
}

const string& ComprobantePago::getCodigoDepartamento() const {
	return codigoDepartamento;
}

const string& ComprobantePago::getNombreDepartamento() const {
	return nombreDepartamento;
}

const DesglosePago& ComprobantePago::getDesglose() const {
	return desglose;
}

void ComprobantePago::marcarPagado(const string& fecha) {
	if (pagado) {
		throw logic_error(
						  "El comprobante " + to_string(numero) +
						  " ya fue pagado.");
	}
	
	if (fecha.empty()) {
		throw invalid_argument(
							   "La fecha de pago no puede estar vacia.");
	}
	
	pagado = true;
	fechaPago = fecha;
}

void ComprobantePago::desvincularEmpleado() {
	empleado = nullptr;
}

void ComprobantePago::desvincularDepartamento() {
	departamento = nullptr;
}
