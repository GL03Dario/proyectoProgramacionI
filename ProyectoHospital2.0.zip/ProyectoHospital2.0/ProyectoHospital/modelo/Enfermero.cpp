#include "modelo/Enfermero.h"
#include <stdexcept>

using namespace std;

Enfermero::Enfermero(
					 const string& identificacion,
					 const string& nombre,
					 double salarioBase,
					 double horasExtra,
					 double valorHoraExtra,
					 int turnosNocturnos,
					 double bonificacionTurnoNocturno,
					 int guardias,
					 double bonificacionGuardia,
					 double tasaDeduccionLegal,
					 const string& areaAsignada,
					 double bonificacionArea)
	
	: Empleado(
			   identificacion,
			   nombre,
			   salarioBase,
			   horasExtra,
			   valorHoraExtra,
			   turnosNocturnos,
			   bonificacionTurnoNocturno,
			   guardias,
			   bonificacionGuardia,
			   tasaDeduccionLegal
			   ),
	
	areaAsignada(areaAsignada),
	bonificacionArea(bonificacionArea) {
	
	if (areaAsignada.empty()) {
		throw invalid_argument(
							   "El area asignada no puede estar vacia.");
	}
	
	validarMonto(
				 bonificacionArea,
				 "bonificacion del area");
}

string Enfermero::obtenerTipo() const {
	return "Enfermero";
}

string Enfermero::obtenerDetallePuesto() const {
	return areaAsignada;
}

void Enfermero::setDetallePuesto(const string& valor) {
	if (valor.empty()) {
		throw invalid_argument(
							   "El area asignada no puede estar vacia.");
	}
	
	areaAsignada = valor;
}

double Enfermero::calcularBonificacionPuesto() const {
	return bonificacionArea;
}

void Enfermero::setBonificacionPuesto(double valor) {
	validarMonto(valor, "bonificacion del area");
	bonificacionArea = valor;
}

const string& Enfermero::getAreaAsignada() const {
	return areaAsignada;
}

double Enfermero::getBonificacionArea() const {
	return bonificacionArea;
}
