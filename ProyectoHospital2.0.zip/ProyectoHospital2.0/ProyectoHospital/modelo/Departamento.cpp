#include "modelo/Departamento.h"
#include <stdexcept>

using namespace std;

Departamento::Departamento(
						   const string& codigo, const string& nombre)
	: codigo(codigo), nombre(nombre) {
	
	if (codigo.empty()) {
		throw invalid_argument(
							   "El codigo del departamento no puede estar vacio.");
	}
	
	if (nombre.empty()) {
		throw invalid_argument(
							   "El nombre del departamento no puede estar vacio.");
	}
}

const string& Departamento::getCodigo() const {
	return codigo;
}

const string& Departamento::getNombre() const {
	return nombre;
}

void Departamento::setNombre(const string& nuevoNombre) {
	if (nuevoNombre.empty()) {
		throw invalid_argument(
							   "El nombre del departamento no puede estar vacio.");
	}
	
	nombre = nuevoNombre;
}

void Departamento::agregarPuesto(
								 const string& codigoPuesto,
								 const string& nombrePuesto) {
	
	if (existePuesto(codigoPuesto)) {
		throw invalid_argument(
							   "Ya existe un puesto con el codigo " + codigoPuesto +
							   " en el departamento " + codigo + ".");
	}
	
	puestos.agregar(new Puesto(codigoPuesto, nombrePuesto));
}

bool Departamento::eliminarPuesto(const string& codigoPuesto) {
	Puesto* puesto = buscarPuesto(codigoPuesto);
	
	if (puesto == nullptr) {
		return false;
	}
	
	return puestos.eliminar(puesto);
}

Puesto* Departamento::buscarPuesto(const string& codigoPuesto) const {
	for (Nodo<Puesto>* nodo = puestos.primero();
	nodo != nullptr;
	nodo = nodo->getSiguiente()) {
		
		if (nodo->getDato()->getCodigo() == codigoPuesto) {
			return nodo->getDato();
		}
	}
	
	return nullptr;
}

bool Departamento::existePuesto(const string& codigoPuesto) const {
	return buscarPuesto(codigoPuesto) != nullptr;
}

const Lista<Puesto>& Departamento::getPuestos() const {
	return puestos;
}
