#include "modelo/Administrativo.h"
#include <stdexcept>

using namespace std;

Administrativo::Administrativo(
							   const string& identificacion,
							   const string& nombre,
							   double salarioBase,
							   double horasExtra,
							   double valorHoraExtra,
							   int turnosNocturnos,
							   double bonificacionTurnoNocturno,
							   int guardias,
							   double bonificacionGuardia,
							   double tasaDeduccionLegal,
							   const string& cargo,
							   double bonificacionCargo)
	
	: Empleado(
			   identificacion,
			   nombre,
			   salarioBase,
			   horasExtra,
			   valorHoraExtra,
			   turnosNocturnos,
			   bonificacionTurnoNocturno,
			   guardias,
			   bonificacionGuardia,
			   tasaDeduccionLegal
			   ),
	
	cargo(cargo),
	bonificacionCargo(bonificacionCargo) {
	
	if (cargo.empty()) {
		throw invalid_argument(
							   "El cargo no puede estar vacio.");
	}
	
	validarMonto(
				 bonificacionCargo,
				 "bonificacion del cargo");
}

string Administrativo::obtenerTipo() const {
	return "Administrativo";
}

string Administrativo::obtenerDetallePuesto() const {
	return cargo;
}

void Administrativo::setDetallePuesto(const string& valor) {
	if (valor.empty()) {
		throw invalid_argument(
							   "El cargo no puede estar vacio.");
	}
	
	cargo = valor;
}

double Administrativo::calcularBonificacionPuesto() const {
	return bonificacionCargo;
}

void Administrativo::setBonificacionPuesto(double valor) {
	validarMonto(valor, "bonificacion del cargo");
	bonificacionCargo = valor;
}

const string& Administrativo::getCargo() const {
	return cargo;
}

double Administrativo::getBonificacionCargo() const {
	return bonificacionCargo;
}
