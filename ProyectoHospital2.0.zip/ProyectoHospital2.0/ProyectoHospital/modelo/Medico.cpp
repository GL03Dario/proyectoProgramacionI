#include "modelo/Medico.h"
#include <stdexcept>

using namespace std;

Medico::Medico(
			   const string& identificacion,
			   const string& nombre,
			   double salarioBase,
			   double horasExtra,
			   double valorHoraExtra,
			   int turnosNocturnos,
			   double bonificacionTurnoNocturno,
			   int guardias,
			   double bonificacionGuardia,
			   double tasaDeduccionLegal,
			   const string& especialidad,
			   double bonificacionEspecialidad)
	
	: Empleado(
			   identificacion,
			   nombre,
			   salarioBase,
			   horasExtra,
			   valorHoraExtra,
			   turnosNocturnos,
			   bonificacionTurnoNocturno,
			   guardias,
			   bonificacionGuardia,
			   tasaDeduccionLegal
			   ),
	
	especialidad(especialidad),
	bonificacionEspecialidad(bonificacionEspecialidad) {
	
	if (especialidad.empty()) {
		throw invalid_argument(
							   "La especialidad no puede estar vacia.");
	}
	
	validarMonto(
				 bonificacionEspecialidad,
				 "bonificacion de especialidad");
}

string Medico::obtenerTipo() const {
	return "Medico";
}

string Medico::obtenerDetallePuesto() const {
	return especialidad;
}

void Medico::setDetallePuesto(const string& valor) {
	if (valor.empty()) {
		throw invalid_argument(
							   "La especialidad no puede estar vacia.");
	}
	
	especialidad = valor;
}

double Medico::calcularBonificacionPuesto() const {
	return bonificacionEspecialidad;
}

void Medico::setBonificacionPuesto(double valor) {
	validarMonto(valor, "bonificacion de especialidad");
	bonificacionEspecialidad = valor;
}

const string& Medico::getEspecialidad() const {
	return especialidad;
}

double Medico::getBonificacionEspecialidad() const {
	return bonificacionEspecialidad;
}
