#ifndef COMPROBANTEPAGO_H
#define COMPROBANTEPAGO_H

#include "modelo/Departamento.h"
#include "modelo/Empleado.h"
#include <string>

struct DesglosePago {
	double salarioBase = 0.0;
	double pagoHorasExtra = 0.0;
	double bonificacionNocturna = 0.0;
	double bonificacionGuardias = 0.0;
	double bonificacionPuesto = 0.0;
	double salarioBruto = 0.0;
	double deduccionLegal = 0.0;
	double salarioNeto = 0.0;
};

class ComprobantePago {
private:
	int numero;
	std::string periodo;
	std::string fechaEmision;
	bool pagado;
	std::string fechaPago;
	
	const Empleado* empleado;
	const Departamento* departamento;
	
	std::string idEmpleado;
	std::string nombreEmpleado;
	std::string tipoEmpleado;
	std::string codigoDepartamento;
	std::string nombreDepartamento;
	
	DesglosePago desglose;
	
	static void validarEncabezado(
								  int numero,
								  const std::string& periodo,
								  const std::string& fechaEmision);
	
public:
	ComprobantePago(
					int numero,
					const std::string& periodo,
					const std::string& fechaEmision,
					const Empleado* empleado,
					const Departamento* departamento);
	
	ComprobantePago(
					int numero,
					const std::string& periodo,
					const std::string& fechaEmision,
					bool pagado,
					const std::string& fechaPago,
					const std::string& idEmpleado,
					const std::string& nombreEmpleado,
					const std::string& tipoEmpleado,
					const std::string& codigoDepartamento,
					const std::string& nombreDepartamento,
					const DesglosePago& desglose,
					const Empleado* empleado,
					const Departamento* departamento);
	
	ComprobantePago(const ComprobantePago&) = delete;
	ComprobantePago& operator=(const ComprobantePago&) = delete;
	
	int getNumero() const;
	const std::string& getPeriodo() const;
	const std::string& getFechaEmision() const;
	bool estaPagado() const;
	const std::string& getFechaPago() const;
	
	const Empleado* getEmpleado() const;
	const Departamento* getDepartamento() const;
	
	const std::string& getIdEmpleado() const;
	const std::string& getNombreEmpleado() const;
	const std::string& getTipoEmpleado() const;
	const std::string& getCodigoDepartamento() const;
	const std::string& getNombreDepartamento() const;
	
	const DesglosePago& getDesglose() const;
	
	void marcarPagado(const std::string& fecha);
	
	void desvincularEmpleado();
	void desvincularDepartamento();
};

#endif
