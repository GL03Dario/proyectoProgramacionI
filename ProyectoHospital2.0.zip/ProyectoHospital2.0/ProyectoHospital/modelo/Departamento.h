#ifndef DEPARTAMENTO_H
#define DEPARTAMENTO_H

#include "colecciones/Lista.h"
#include "modelo/Puesto.h"
#include <string>

class Departamento {
private:
	std::string codigo;
	std::string nombre;
	Lista<Puesto> puestos;
	
public:
	Departamento(const std::string& codigo, const std::string& nombre);
	
	Departamento(const Departamento&) = delete;
	Departamento& operator=(const Departamento&) = delete;
	
	const std::string& getCodigo() const;
	const std::string& getNombre() const;
	void setNombre(const std::string& nuevoNombre);
	
	void agregarPuesto(
					   const std::string& codigoPuesto,
					   const std::string& nombrePuesto);
	
	bool eliminarPuesto(const std::string& codigoPuesto);
	
	Puesto* buscarPuesto(const std::string& codigoPuesto) const;
	bool existePuesto(const std::string& codigoPuesto) const;
	
	const Lista<Puesto>& getPuestos() const;
};

#endif
