#ifndef FABRICAEMPLEADO_H
#define FABRICAEMPLEADO_H

#include "modelo/Empleado.h"
#include <string>

struct DatosEmpleado {
	std::string tipo;
	std::string identificacion;
	std::string nombre;
	double salarioBase = 0.0;
	double horasExtra = 0.0;
	double valorHoraExtra = 0.0;
	int turnosNocturnos = 0;
	double bonificacionTurnoNocturno = 0.0;
	int guardias = 0;
	double bonificacionGuardia = 0.0;
	double tasaDeduccionLegal = 0.0;
	std::string detallePuesto;
	double bonificacionPuesto = 0.0;
	std::string idDepartamento;
	std::string codigoPuesto;
};

class FabricaEmpleado {
public:
	FabricaEmpleado() = default;
	
	FabricaEmpleado(const FabricaEmpleado&) = delete;
	FabricaEmpleado& operator=(const FabricaEmpleado&) = delete;
	
	bool soporta(const std::string& tipo) const;
	
	std::string obtenerEtiquetaDetalle(const std::string& tipo) const;
	
	Empleado* crear(const DatosEmpleado& datos) const;
	
	int cantidadTipos() const;
	std::string obtenerTipoPorIndice(int indice) const;
};

#endif
