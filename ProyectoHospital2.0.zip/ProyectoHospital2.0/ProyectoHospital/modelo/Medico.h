#ifndef MEDICO_H
#define MEDICO_H

#include "modelo/Empleado.h"
#include <string>

class Medico : public Empleado {
	
private:
	std::string especialidad;
	double bonificacionEspecialidad;
	
public:
	Medico(
		   const std::string& identificacion,
		   const std::string& nombre,
		   double salarioBase,
		   double horasExtra,
		   double valorHoraExtra,
		   int turnosNocturnos,
		   double bonificacionTurnoNocturno,
		   int guardias,
		   double bonificacionGuardia,
		   double tasaDeduccionLegal,
		   const std::string& especialidad,
		   double bonificacionEspecialidad
		   );
	
	std::string obtenerTipo() const override;
	
	std::string obtenerDetallePuesto() const override;
	void setDetallePuesto(const std::string& valor) override;
	
	double calcularBonificacionPuesto() const override;
	void setBonificacionPuesto(double valor) override;
	
	const std::string& getEspecialidad() const;
	double getBonificacionEspecialidad() const;
};

#endif
