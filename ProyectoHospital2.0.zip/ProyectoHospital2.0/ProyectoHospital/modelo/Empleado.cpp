#include "modelo/Empleado.h"
#include <stdexcept>

using namespace std;

Empleado::Empleado(
				   const string& identificacion,
				   const string& nombre,
				   double salarioBase,
				   double horasExtra,
				   double valorHoraExtra,
				   int turnosNocturnos,
				   double bonificacionTurnoNocturno,
				   int guardias,
				   double bonificacionGuardia,
				   double tasaDeduccionLegal)
	
	: identificacion(identificacion),
	nombre(nombre),
	salarioBase(salarioBase),
	horasExtra(horasExtra),
	valorHoraExtra(valorHoraExtra),
	turnosNocturnos(turnosNocturnos),
	bonificacionTurnoNocturno(bonificacionTurnoNocturno),
	guardias(guardias),
	bonificacionGuardia(bonificacionGuardia),
	tasaDeduccionLegal(tasaDeduccionLegal),
	idDepartamento(),
	codigoPuesto() {
	
	if (identificacion.empty())
		throw invalid_argument(
							   "La identificacion no puede estar vacia.");
	
	if (nombre.empty())
		throw invalid_argument(
							   "El nombre no puede estar vacio.");
	
	validarMonto(salarioBase, "salario base");
	validarMonto(horasExtra, "horas extra");
	validarMonto(valorHoraExtra, "valor de hora extra");
	
	validarMonto(
				 bonificacionTurnoNocturno,
				 "bonificacion nocturna");
	
	validarMonto(
				 bonificacionGuardia,
				 "bonificacion por guardia");
	
	validarCantidad(turnosNocturnos, "turnos nocturnos");
	validarCantidad(guardias, "guardias");
	
	if (tasaDeduccionLegal < 0.0 ||
		tasaDeduccionLegal > 1.0) {
		
		throw invalid_argument(
							   "La tasa de deduccion debe estar entre 0 y 1.");
	}
}

Empleado::~Empleado() = default;

void Empleado::validarMonto(
							double valor, const string& campo) {
	
	if (valor < 0.0) {
		throw invalid_argument(
							   "El valor de " + campo + " no puede ser negativo.");
	}
}

void Empleado::validarCantidad(
							   int valor, const string& campo) {
	
	if (valor < 0) {
		throw invalid_argument(
							   "La cantidad de " + campo + " no puede ser negativa.");
	}
}

double Empleado::calcularPagoHorasExtra() const {
	return horasExtra * valorHoraExtra;
}

double Empleado::calcularBonificacionNocturna() const {
	return turnosNocturnos * bonificacionTurnoNocturno;
}

double Empleado::calcularBonificacionGuardias() const {
	return guardias * bonificacionGuardia;
}

double Empleado::calcularSalarioBruto() const {
	
	return salarioBase
		+ calcularPagoHorasExtra()
		+ calcularBonificacionNocturna()
		+ calcularBonificacionGuardias()
		+ calcularBonificacionPuesto();
}

double Empleado::calcularDeduccionLegal() const {
	return calcularSalarioBruto() * tasaDeduccionLegal;
}

double Empleado::calcularSalarioNeto() const {
	return calcularSalarioBruto()
		- calcularDeduccionLegal();
}

const string& Empleado::getIdentificacion() const {
	return identificacion;
}

const string& Empleado::getNombre() const {
	return nombre;
}

double Empleado::getSalarioBase() const {
	return salarioBase;
}

double Empleado::getHorasExtra() const {
	return horasExtra;
}

double Empleado::getValorHoraExtra() const {
	return valorHoraExtra;
}

int Empleado::getTurnosNocturnos() const {
	return turnosNocturnos;
}

double Empleado::getBonificacionTurnoNocturno() const {
	return bonificacionTurnoNocturno;
}

int Empleado::getGuardias() const {
	return guardias;
}

double Empleado::getBonificacionGuardia() const {
	return bonificacionGuardia;
}

double Empleado::getTasaDeduccionLegal() const {
	return tasaDeduccionLegal;
}

const string& Empleado::getIdDepartamento() const {
	return idDepartamento;
}

const string& Empleado::getCodigoPuesto() const {
	return codigoPuesto;
}

void Empleado::setNombre(const string& valor) {
	if (valor.empty())
		throw invalid_argument(
							   "El nombre no puede estar vacio.");
	
	nombre = valor;
}

void Empleado::setSalarioBase(double valor) {
	validarMonto(valor, "salario base");
	salarioBase = valor;
}

void Empleado::setHorasExtra(double valor) {
	validarMonto(valor, "horas extra");
	horasExtra = valor;
}

void Empleado::setValorHoraExtra(double valor) {
	validarMonto(valor, "valor de hora extra");
	valorHoraExtra = valor;
}

void Empleado::setTurnosNocturnos(int valor) {
	validarCantidad(valor, "turnos nocturnos");
	turnosNocturnos = valor;
}

void Empleado::setBonificacionTurnoNocturno(double valor) {
	validarMonto(valor, "bonificacion nocturna");
	bonificacionTurnoNocturno = valor;
}

void Empleado::setGuardias(int valor) {
	validarCantidad(valor, "guardias");
	guardias = valor;
}

void Empleado::setBonificacionGuardia(double valor) {
	validarMonto(valor, "bonificacion por guardia");
	bonificacionGuardia = valor;
}

void Empleado::setTasaDeduccionLegal(double valor) {
	if (valor < 0.0 || valor > 1.0)
		throw invalid_argument(
							   "La tasa de deduccion debe estar entre 0 y 1.");
	
	tasaDeduccionLegal = valor;
}

void Empleado::setIdDepartamento(const string& valor) {
	idDepartamento = valor;
}

void Empleado::setCodigoPuesto(const string& valor) {
	codigoPuesto = valor;
}
