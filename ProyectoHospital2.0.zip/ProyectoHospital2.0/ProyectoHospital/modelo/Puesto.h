#ifndef PUESTO_H
#define PUESTO_H

#include <string>

class Puesto {
private:
	std::string codigo;
	std::string nombre;
	
public:
	Puesto(const std::string& codigo, const std::string& nombre);
	
	const std::string& getCodigo() const;
	const std::string& getNombre() const;
	
	void setNombre(const std::string& nuevoNombre);
};

#endif
