#include "modelo/Puesto.h"
#include <stdexcept>

using namespace std;

Puesto::Puesto(const string& codigo, const string& nombre)
	: codigo(codigo), nombre(nombre) {
	
	if (codigo.empty()) {
		throw invalid_argument(
							   "El codigo del puesto no puede estar vacio.");
	}
	
	if (nombre.empty()) {
		throw invalid_argument(
							   "El nombre del puesto no puede estar vacio.");
	}
}

const string& Puesto::getCodigo() const {
	return codigo;
}

const string& Puesto::getNombre() const {
	return nombre;
}

void Puesto::setNombre(const string& nuevoNombre) {
	if (nuevoNombre.empty()) {
		throw invalid_argument(
							   "El nombre del puesto no puede estar vacio.");
	}
	
	nombre = nuevoNombre;
}
