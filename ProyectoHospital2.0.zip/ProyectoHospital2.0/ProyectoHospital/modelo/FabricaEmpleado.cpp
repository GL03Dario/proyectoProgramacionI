#include "modelo/FabricaEmpleado.h"
#include "modelo/Administrativo.h"
#include "modelo/Enfermero.h"
#include "modelo/Medico.h"
#include <stdexcept>

using namespace std;

bool FabricaEmpleado::soporta(const string& tipo) const {
	return tipo == "Medico" ||
		tipo == "Enfermero" ||
		tipo == "Administrativo";
}

string FabricaEmpleado::obtenerEtiquetaDetalle(const string& tipo) const {
	if (tipo == "Medico") {
		return "Especialidad";
	}
	
	if (tipo == "Enfermero") {
		return "Area asignada";
	}
	
	if (tipo == "Administrativo") {
		return "Cargo";
	}
	
	return "Detalle del puesto";
}

Empleado* FabricaEmpleado::crear(const DatosEmpleado& d) const {
	Empleado* e = nullptr;
	
	if (d.tipo == "Medico") {
		e = new Medico(
					   d.identificacion, d.nombre, d.salarioBase,
					   d.horasExtra, d.valorHoraExtra,
					   d.turnosNocturnos, d.bonificacionTurnoNocturno,
					   d.guardias, d.bonificacionGuardia,
					   d.tasaDeduccionLegal,
					   d.detallePuesto, d.bonificacionPuesto);
		
	} else if (d.tipo == "Enfermero") {
		e = new Enfermero(
						  d.identificacion, d.nombre, d.salarioBase,
						  d.horasExtra, d.valorHoraExtra,
						  d.turnosNocturnos, d.bonificacionTurnoNocturno,
						  d.guardias, d.bonificacionGuardia,
						  d.tasaDeduccionLegal,
						  d.detallePuesto, d.bonificacionPuesto);
		
	} else if (d.tipo == "Administrativo") {
		e = new Administrativo(
							   d.identificacion, d.nombre, d.salarioBase,
							   d.horasExtra, d.valorHoraExtra,
							   d.turnosNocturnos, d.bonificacionTurnoNocturno,
							   d.guardias, d.bonificacionGuardia,
							   d.tasaDeduccionLegal,
							   d.detallePuesto, d.bonificacionPuesto);
		
	} else {
		throw invalid_argument(
							   "Tipo de empleado desconocido: " + d.tipo);
	}
	
	e->setIdDepartamento(d.idDepartamento);
	e->setCodigoPuesto(d.codigoPuesto);
	return e;
}

int FabricaEmpleado::cantidadTipos() const {
	return 3;
}

string FabricaEmpleado::obtenerTipoPorIndice(int indice) const {
	if (indice == 0) {
		return "Medico";
	}
	
	if (indice == 1) {
		return "Enfermero";
	}
	
	if (indice == 2) {
		return "Administrativo";
	}
	
	throw out_of_range(
					   "Indice de tipo fuera de rango: " + to_string(indice));
}
