#ifndef EMPLEADO_H
#define EMPLEADO_H

#include <string>

class Empleado {
private:
	std::string identificacion;
	std::string nombre;
	double salarioBase;
	double horasExtra;
	double valorHoraExtra;
	int turnosNocturnos;
	double bonificacionTurnoNocturno;
	int guardias;
	double bonificacionGuardia;
	double tasaDeduccionLegal;
	
	std::string idDepartamento;
	std::string codigoPuesto;
	
protected:
	Empleado(const std::string& identificacion,
			 const std::string& nombre,
			 double salarioBase,
			 double horasExtra,
			 double valorHoraExtra,
			 int turnosNocturnos,
			 double bonificacionTurnoNocturno,
			 int guardias,
			 double bonificacionGuardia,
			 double tasaDeduccionLegal);
	
	static void validarMonto(
							 double valor, const std::string& campo);
	
	static void validarCantidad(
								int valor, const std::string& campo);
	
public:
	Empleado(const Empleado&) = delete;
	Empleado& operator=(const Empleado&) = delete;
	
	virtual ~Empleado();
	
	virtual std::string obtenerTipo() const = 0;
	
	virtual std::string obtenerDetallePuesto() const = 0;
	virtual void setDetallePuesto(const std::string& valor) = 0;
	
	virtual double calcularBonificacionPuesto() const = 0;
	virtual void setBonificacionPuesto(double valor) = 0;
	
	double calcularPagoHorasExtra() const;
	double calcularBonificacionNocturna() const;
	double calcularBonificacionGuardias() const;
	
	double calcularSalarioBruto() const;
	double calcularDeduccionLegal() const;
	double calcularSalarioNeto() const;
	
	const std::string& getIdentificacion() const;
	const std::string& getNombre() const;
	
	double getSalarioBase() const;
	double getHorasExtra() const;
	double getValorHoraExtra() const;
	
	int getTurnosNocturnos() const;
	double getBonificacionTurnoNocturno() const;
	
	int getGuardias() const;
	double getBonificacionGuardia() const;
	
	double getTasaDeduccionLegal() const;
	
	const std::string& getIdDepartamento() const;
	const std::string& getCodigoPuesto() const;
	
	void setNombre(const std::string& valor);
	void setSalarioBase(double valor);
	void setHorasExtra(double valor);
	void setValorHoraExtra(double valor);
	void setTurnosNocturnos(int valor);
	void setBonificacionTurnoNocturno(double valor);
	void setGuardias(int valor);
	void setBonificacionGuardia(double valor);
	void setTasaDeduccionLegal(double valor);
	
	void setIdDepartamento(const std::string& valor);
	void setCodigoPuesto(const std::string& valor);
};

#endif
