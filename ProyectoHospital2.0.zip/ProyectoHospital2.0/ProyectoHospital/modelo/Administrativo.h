#ifndef ADMINISTRATIVO_H
#define ADMINISTRATIVO_H

#include "modelo/Empleado.h"
#include <string>

class Administrativo : public Empleado {
	
private:
	std::string cargo;
	double bonificacionCargo;
	
public:
	Administrativo(
				   const std::string& identificacion,
				   const std::string& nombre,
				   double salarioBase,
				   double horasExtra,
				   double valorHoraExtra,
				   int turnosNocturnos,
				   double bonificacionTurnoNocturno,
				   int guardias,
				   double bonificacionGuardia,
				   double tasaDeduccionLegal,
				   const std::string& cargo,
				   double bonificacionCargo
				   );
	
	std::string obtenerTipo() const override;
	
	std::string obtenerDetallePuesto() const override;
	void setDetallePuesto(const std::string& valor) override;
	
	double calcularBonificacionPuesto() const override;
	void setBonificacionPuesto(double valor) override;
	
	const std::string& getCargo() const;
	double getBonificacionCargo() const;
};

#endif
