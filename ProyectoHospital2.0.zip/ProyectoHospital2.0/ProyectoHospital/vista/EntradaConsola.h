#ifndef ENTRADACONSOLA_H
#define ENTRADACONSOLA_H

#include <stdexcept>
#include <string>

class EntradaFinalizada : public std::runtime_error {
public:
	EntradaFinalizada()
		: std::runtime_error("Se cerro la entrada estandar.") {}
};

class EntradaConsola {
private:
	static std::string leerLinea(const std::string& mensaje);
	
public:
	static std::string leerTexto(
								 const std::string& mensaje, bool permitirVacio = false);
	
	static int leerEntero(
						  const std::string& mensaje, int minimo, int maximo = 1000000);
	
	static double leerDecimal(
							  const std::string& mensaje,
							  double minimo = 0.0,
							  double maximo = 1000000000000.0);
	
	static bool confirmar(const std::string& mensaje);
	
	static std::string leerPeriodo(const std::string& mensaje);
	
	static void pausar();
};

#endif
