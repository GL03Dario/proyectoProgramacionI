#include "vista/EntradaConsola.h"
#include <cctype>
#include <iostream>
#include <sstream>

using namespace std;

namespace {
	
	string recortar(const string& texto) {
		size_t inicio = 0;
		size_t fin = texto.size();
		
		while (inicio < fin &&
			   isspace(static_cast<unsigned char>(texto[inicio]))) {
			++inicio;
		}
			   
			   while (fin > inicio &&
					  isspace(static_cast<unsigned char>(texto[fin - 1]))) {
				   --fin;
			   }
					  
					  return texto.substr(inicio, fin - inicio);
	}
	
	bool esPeriodoValido(const string& periodo) {
		if (periodo.size() != 7 || periodo[4] != '-') {
			return false;
		}
		
		for (size_t i = 0; i < periodo.size(); ++i) {
			if (i != 4 &&
				!isdigit(static_cast<unsigned char>(periodo[i]))) {
				return false;
			}
		}
		
		int mes = stoi(periodo.substr(5, 2));
		return mes >= 1 && mes <= 12;
	}
	
}

string EntradaConsola::leerLinea(const string& mensaje) {
	cout << mensaje;
	
	string linea;
	
	if (!getline(cin, linea)) {
		throw EntradaFinalizada();
	}
	
	return recortar(linea);
}

string EntradaConsola::leerTexto(
								 const string& mensaje, bool permitirVacio) {
	
	while (true) {
		string texto = leerLinea(mensaje);
		
		if (texto.empty() && !permitirVacio) {
			cout << "  Error: el valor no puede estar vacio.\n";
			continue;
		}
		
		if (texto.find('|') != string::npos) {
			cout << "  Error: el caracter '|' no esta permitido.\n";
			continue;
		}
		
		return texto;
	}
}

int EntradaConsola::leerEntero(
							   const string& mensaje, int minimo, int maximo) {
	
	while (true) {
		string texto = leerLinea(mensaje);
		size_t posicion = 0;
		int valor = 0;
		
		try {
			valor = stoi(texto, &posicion);
		} catch (const exception&) {
			cout << "  Error: debe ingresar un numero entero.\n";
			continue;
		}
		
		if (posicion != texto.size()) {
			cout << "  Error: debe ingresar un numero entero.\n";
			continue;
		}
		
		if (valor < minimo || valor > maximo) {
			cout << "  Error: el valor debe estar entre "
				<< minimo << " y " << maximo << ".\n";
			continue;
		}
		
		return valor;
	}
}

double EntradaConsola::leerDecimal(
								   const string& mensaje, double minimo, double maximo) {
	
	while (true) {
		string texto = leerLinea(mensaje);
		
		for (char& c : texto) {
			if (c == ',') {
				c = '.';
			}
		}
		
		istringstream flujo(texto);
		double valor = 0.0;
		flujo >> valor;
		
		if (flujo.fail()) {
			cout << "  Error: debe ingresar un numero.\n";
			continue;
		}
		
		flujo >> ws;
		
		if (!flujo.eof()) {
			cout << "  Error: debe ingresar un numero.\n";
			continue;
		}
		
		if (valor < minimo || valor > maximo) {
			cout << "  Error: el valor debe estar entre "
				<< minimo << " y " << maximo << ".\n";
			continue;
		}
		
		return valor;
	}
}

bool EntradaConsola::confirmar(const string& mensaje) {
	while (true) {
		string texto = leerLinea(mensaje + " (s/n): ");
		
		for (char& c : texto) {
			c = static_cast<char>(
								  tolower(static_cast<unsigned char>(c)));
		}
		
		if (texto == "s" || texto == "si") {
			return true;
		}
		
		if (texto == "n" || texto == "no") {
			return false;
		}
		
		cout << "  Error: responda 's' o 'n'.\n";
	}
}

string EntradaConsola::leerPeriodo(const string& mensaje) {
	while (true) {
		string texto = leerLinea(mensaje);
		
		if (esPeriodoValido(texto)) {
			return texto;
		}
		
		cout << "  Error: use el formato AAAA-MM (ejemplo: 2026-11).\n";
	}
}

void EntradaConsola::pausar() {
	leerLinea("\nPresione Enter para continuar...");
}
