#include "vista/InterfazConsola.h"
#include "vista/EntradaConsola.h"
#include <iomanip>
#include <iostream>
#include <sstream>

using namespace std;

namespace {
	
	string formatearMonto(double valor) {
		ostringstream flujo;
		flujo << fixed << setprecision(2) << valor;
		return flujo.str();
	}
	
	void mostrarTitulo(const string& texto) {
		cout << "\n=== " << texto << " ===\n";
	}
	
	string textoOSinAsignar(const string& valor) {
		return valor.empty() ? "Sin asignar" : valor;
	}
	
}

InterfazConsola::InterfazConsola(
								 ControladorEmpleados& empleados,
								 ControladorDepartamentos& departamentos,
								 ServicioPlanilla& planilla,
								 const FabricaEmpleado& fabrica)
	
	: empleados(empleados),
	departamentos(departamentos),
	planilla(planilla),
	fabrica(fabrica) {}

void InterfazConsola::ejecutar() {
	try {
		bool salir = false;
		
		while (!salir) {
			mostrarTitulo("SISTEMA DE PLANILLA HOSPITALARIA");
			cout << "  1. Gestion de empleados\n"
				<< "  2. Departamentos y puestos\n"
				<< "  3. Planilla y pagos\n"
				<< "  0. Salir\n";
			
			int opcion = EntradaConsola::leerEntero("Opcion: ", 0, 3);
			
			switch (opcion) {
			case 1: menuEmpleados(); break;
			case 2: menuDepartamentos(); break;
			case 3: menuPlanilla(); break;
			case 0: salir = true; break;
			}
		}
		
		cout << "\nLos datos estan guardados. Hasta pronto!\n";
	} catch (const EntradaFinalizada&) {
		cout << "\n\nEntrada finalizada. Saliendo del sistema...\n";
	}
}

void InterfazConsola::menuEmpleados() {
	bool volver = false;
	
	while (!volver) {
		mostrarTitulo("GESTION DE EMPLEADOS");
		cout << "  1. Registrar empleado\n"
			<< "  2. Listar empleados\n"
			<< "  3. Ver detalle y desglose salarial\n"
			<< "  4. Modificar empleado\n"
			<< "  5. Asignar departamento y puesto\n"
			<< "  6. Eliminar empleado\n"
			<< "  0. Volver\n";
		
		int opcion = EntradaConsola::leerEntero("Opcion: ", 0, 6);
		
		try {
			switch (opcion) {
			case 1: registrarEmpleado(); break;
			case 2: listarEmpleados(); break;
			case 3: verDetalleEmpleado(); break;
			case 4: modificarEmpleado(); break;
			case 5: asignarPuestoEmpleado(); break;
			case 6: eliminarEmpleado(); break;
			case 0: volver = true; break;
			}
		} catch (const EntradaFinalizada&) {
			throw;
		} catch (const exception& e) {
			cout << "\n  Error: " << e.what() << "\n";
		}
		
		if (opcion != 0) {
			EntradaConsola::pausar();
		}
	}
}

void InterfazConsola::menuDepartamentos() {
	bool volver = false;
	
	while (!volver) {
		mostrarTitulo("DEPARTAMENTOS Y PUESTOS");
		cout << "  1. Crear departamento\n"
			<< "  2. Listar departamentos y puestos\n"
			<< "  3. Agregar puesto a un departamento\n"
			<< "  4. Eliminar puesto\n"
			<< "  5. Eliminar departamento\n"
			<< "  0. Volver\n";
		
		int opcion = EntradaConsola::leerEntero("Opcion: ", 0, 5);
		
		try {
			switch (opcion) {
			case 1: crearDepartamento(); break;
			case 2: listarDepartamentos(); break;
			case 3: agregarPuesto(); break;
			case 4: eliminarPuesto(); break;
			case 5: eliminarDepartamento(); break;
			case 0: volver = true; break;
			}
		} catch (const EntradaFinalizada&) {
			throw;
		} catch (const exception& e) {
			cout << "\n  Error: " << e.what() << "\n";
		}
		
		if (opcion != 0) {
			EntradaConsola::pausar();
		}
	}
}

void InterfazConsola::menuPlanilla() {
	bool volver = false;
	
	while (!volver) {
		mostrarTitulo("PLANILLA Y PAGOS");
		cout << "  1. Generar comprobante de un empleado\n"
			<< "  2. Generar planilla completa de un periodo\n"
			<< "  3. Listar comprobantes\n"
			<< "  4. Ver un comprobante\n"
			<< "  5. Procesar pago de un comprobante\n"
			<< "  6. Procesar todos los pagos de un periodo\n"
			<< "  7. Resumen de un periodo\n"
			<< "  0. Volver\n";
		
		int opcion = EntradaConsola::leerEntero("Opcion: ", 0, 7);
		
		try {
			switch (opcion) {
			case 1: generarComprobanteIndividual(); break;
			case 2: generarPlanillaPeriodo(); break;
			case 3: listarComprobantes(); break;
			case 4: verComprobante(); break;
			case 5: procesarPagoIndividual(); break;
			case 6: procesarPagosDelPeriodo(); break;
			case 7: mostrarResumenPeriodo(); break;
			case 0: volver = true; break;
			}
		} catch (const EntradaFinalizada&) {
			throw;
		} catch (const exception& e) {
			cout << "\n  Error: " << e.what() << "\n";
		}
		
		if (opcion != 0) {
			EntradaConsola::pausar();
		}
	}
}



Empleado* InterfazConsola::solicitarEmpleadoExistente() {
	string id = EntradaConsola::leerTexto("Identificacion del empleado: ");
	Empleado* empleado = empleados.buscar(id);
	
	if (empleado == nullptr) {
		throw invalid_argument(
							   "No existe un empleado con la identificacion " + id + ".");
	}
	
	return empleado;
}

void InterfazConsola::registrarEmpleado() {
	mostrarTitulo("Registrar empleado");
	
	int total = fabrica.cantidadTipos();
	
	cout << "Tipos de empleado disponibles:\n";
	
	for (int i = 0; i < total; ++i) {
		cout << "  " << (i + 1) << ". "
			<< fabrica.obtenerTipoPorIndice(i) << "\n";
	}
	
	int eleccion = EntradaConsola::leerEntero(
											  "Seleccione el tipo: ", 1, total);
	
	string tipo = fabrica.obtenerTipoPorIndice(eleccion - 1);
	
	DatosEmpleado datos;
	datos.tipo = tipo;
	
	datos.identificacion = EntradaConsola::leerTexto("Identificacion: ");
	datos.nombre = EntradaConsola::leerTexto("Nombre completo: ");
	
	datos.salarioBase = EntradaConsola::leerDecimal("Salario base: ");
	datos.horasExtra = EntradaConsola::leerDecimal("Horas extra del periodo: ");
	datos.valorHoraExtra = EntradaConsola::leerDecimal("Valor por hora extra: ");
	
	datos.turnosNocturnos = EntradaConsola::leerEntero( "Cantidad de turnos nocturnos: ", 0);
	datos.bonificacionTurnoNocturno = EntradaConsola::leerDecimal("Bonificacion por turno nocturno: ");
	
	datos.guardias = EntradaConsola::leerEntero("Cantidad de guardias: ", 0);
	datos.bonificacionGuardia = EntradaConsola::leerDecimal("Bonificacion por guardia: ");
	
	datos.tasaDeduccionLegal = EntradaConsola::leerDecimal("Tasa de deduccion de ley en % (0-100): ", 0.0, 100.0) / 100.0;
	
	datos.detallePuesto = EntradaConsola::leerTexto(fabrica.obtenerEtiquetaDetalle(tipo) + ": ");
	datos.bonificacionPuesto = EntradaConsola::leerDecimal("Bonificacion del puesto (" + fabrica.obtenerEtiquetaDetalle(tipo) + "): ");
	
	if (EntradaConsola::confirmar("Desea asignarlo a un departamento ahora?")) {
		listarDepartamentos();
		
		datos.idDepartamento = EntradaConsola::leerTexto(
														 "Codigo del departamento: ");
		
		if (EntradaConsola::confirmar("Desea asignarle un puesto?")) {
			datos.codigoPuesto = EntradaConsola::leerTexto("Codigo del puesto: ");
		}
	}
	
	Empleado* empleado = empleados.registrar(datos);
	
	cout << "\n  Empleado registrado: " << empleado->getNombre()
		<< " (" << empleado->obtenerTipo() << ")\n";
}

void InterfazConsola::listarEmpleados() const {
	mostrarTitulo("Listado de empleados");
	
	const Lista<Empleado>& lista = empleados.getEmpleados();
	
	if (lista.estaVacia()) {
		cout << "  No hay empleados registrados.\n";
		return;
	}
	
	cout << left
						<< setw(14) << "ID"
						<< setw(16) << "Tipo"
						<< setw(14) << "Departamento"
						<< setw(14) << "Salario neto"
						<< "Nombre\n";
	
	for (Nodo<Empleado>* nodo = lista.primero();
	nodo != nullptr;
	nodo = nodo->getSiguiente()) {
		
		const Empleado* e = nodo->getDato();
		
		cout << left
			<< setw(14) << e->getIdentificacion()
			<< setw(16) << e->obtenerTipo()
			<< setw(14) << textoOSinAsignar(e->getIdDepartamento())
			<< setw(14) << formatearMonto(e->calcularSalarioNeto())
			<< e->getNombre() << "\n";
	}
	
	cout << "\n  Total: " << lista.getTamano() << " empleado(s).\n";
}

void InterfazConsola::mostrarEmpleado(const Empleado* e) const {
	const string etiqueta = fabrica.obtenerEtiquetaDetalle(e->obtenerTipo());
	
	string nombreDepartamento = "Sin asignar";
	
	if (!e->getIdDepartamento().empty()) {
		const Departamento* d = departamentos.buscar(e->getIdDepartamento());
		
		nombreDepartamento = e->getIdDepartamento();
		
		if (d != nullptr) {
			nombreDepartamento += " - " + d->getNombre();
		}
	}
	
	cout << "\n  Tipo:            " << e->obtenerTipo()
									  << "\n  Identificacion:  " << e->getIdentificacion()
									  << "\n  Nombre:          " << e->getNombre()
									  << "\n  " << etiqueta << ": " << e->obtenerDetallePuesto()
									  << "\n  Departamento:    " << nombreDepartamento
									  << "\n  Puesto:          " << textoOSinAsignar(e->getCodigoPuesto())
									  << "\n";
	
	cout << "\n  --- Desglose salarial ---"
		<< "\n  Salario base:                 " << formatearMonto(e->getSalarioBase())
		<< "\n  Horas extra (" << e->getHorasExtra() << " x "
		<< formatearMonto(e->getValorHoraExtra()) << "):  "
		<< formatearMonto(e->calcularPagoHorasExtra())
		<< "\n  Turnos nocturnos (" << e->getTurnosNocturnos() << " x "
		<< formatearMonto(e->getBonificacionTurnoNocturno()) << "):  "
		<< formatearMonto(e->calcularBonificacionNocturna())
		<< "\n  Guardias (" << e->getGuardias() << " x "
		<< formatearMonto(e->getBonificacionGuardia()) << "):  "
		<< formatearMonto(e->calcularBonificacionGuardias())
		<< "\n  Bonificacion del puesto:      "
		<< formatearMonto(e->calcularBonificacionPuesto())
		<< "\n  Salario bruto:                " << formatearMonto(e->calcularSalarioBruto())
		<< "\n  Deduccion de ley ("
		<< formatearMonto(e->getTasaDeduccionLegal() * 100.0) << "%):  "
		<< formatearMonto(e->calcularDeduccionLegal())
		<< "\n  SALARIO NETO:                 " << formatearMonto(e->calcularSalarioNeto())
		<< "\n";
}

void InterfazConsola::verDetalleEmpleado() {
	mostrarTitulo("Detalle de empleado");
	mostrarEmpleado(solicitarEmpleadoExistente());
}

void InterfazConsola::modificarEmpleado() {
	mostrarTitulo("Modificar empleado");
	
	Empleado* e = solicitarEmpleadoExistente();
	mostrarEmpleado(e);
	
	const string etiqueta = fabrica.obtenerEtiquetaDetalle(e->obtenerTipo());
	
	cout << "\nCampos modificables:\n"
		<< "   1. Nombre\n"
		<< "   2. Salario base\n"
		<< "   3. Horas extra\n"
		<< "   4. Valor por hora extra\n"
		<< "   5. Turnos nocturnos\n"
		<< "   6. Bonificacion por turno nocturno\n"
		<< "   7. Guardias\n"
		<< "   8. Bonificacion por guardia\n"
		<< "   9. Tasa de deduccion de ley\n"
		<< "  10. " << etiqueta << "\n"
		<< "  11. Bonificacion del puesto\n"
		<< "   0. Cancelar\n";
	
	int campo = EntradaConsola::leerEntero("Campo a modificar: ", 0, 11);
	
	switch (campo) {
	case 1:
		e->setNombre(EntradaConsola::leerTexto("Nuevo nombre: "));
		break;
	case 2:
		e->setSalarioBase(EntradaConsola::leerDecimal("Nuevo salario base: "));
		break;
	case 3:
		e->setHorasExtra(EntradaConsola::leerDecimal("Nuevas horas extra: "));
		break;
	case 4:
		e->setValorHoraExtra(EntradaConsola::leerDecimal("Nuevo valor por hora extra: "));
		break;
	case 5:
		e->setTurnosNocturnos(EntradaConsola::leerEntero("Nuevos turnos nocturnos: ", 0));
		break;
	case 6:
		e->setBonificacionTurnoNocturno(EntradaConsola::leerDecimal("Nueva bonificacion nocturna: "));
		break;
	case 7:
		e->setGuardias(EntradaConsola::leerEntero("Nueva cantidad de guardias: ", 0));
		break;
	case 8:
		e->setBonificacionGuardia(EntradaConsola::leerDecimal("Nueva bonificacion por guardia: "));
		break;
	case 9:
		e->setTasaDeduccionLegal(
								 EntradaConsola::leerDecimal("Nueva tasa de deduccion en % (0-100): ", 0.0, 100.0) / 100.0);
		break;
	case 10:
		e->setDetallePuesto(EntradaConsola::leerTexto("Nuevo valor de " + etiqueta + ": "));
		break;
	case 11:
		e->setBonificacionPuesto(EntradaConsola::leerDecimal("Nueva bonificacion del puesto: "));
		break;
	case 0:
		cout << "  Operacion cancelada.\n";
		return;
	}
	
	empleados.guardar();
	cout << "\n  Empleado actualizado correctamente.\n";
}

void InterfazConsola::asignarPuestoEmpleado() {
	mostrarTitulo("Asignar departamento y puesto");
	
	Empleado* e = solicitarEmpleadoExistente();
	
	listarDepartamentos();
	
	string idDepartamento = EntradaConsola::leerTexto(
													  "Codigo del departamento (vacio para quitar la asignacion): ", true);
	
	string codigoPuesto;
	
	if (!idDepartamento.empty()) {
		codigoPuesto = EntradaConsola::leerTexto(
												 "Codigo del puesto (vacio para ninguno): ", true);
	}
	
	empleados.asignarPuesto(e->getIdentificacion(), idDepartamento, codigoPuesto);
	cout << "\n  Asignacion actualizada correctamente.\n";
}

void InterfazConsola::eliminarEmpleado() {
	mostrarTitulo("Eliminar empleado");
	
	Empleado* e = solicitarEmpleadoExistente();
	mostrarEmpleado(e);
	
	if (!EntradaConsola::confirmar("\nSeguro que desea eliminar a este empleado?")) {
		cout << "  Operacion cancelada.\n";
		return;
	}
	
	const string id = e->getIdentificacion();
	planilla.desvincularEmpleado(id);
	empleados.eliminar(id);
	
	cout << "\n  Empleado eliminado. Sus comprobantes se conservan en el historial.\n";
}



void InterfazConsola::crearDepartamento() {
	mostrarTitulo("Crear departamento");
	
	string codigo = EntradaConsola::leerTexto("Codigo: ");
	string nombre = EntradaConsola::leerTexto("Nombre: ");
	
	departamentos.crear(codigo, nombre);
	cout << "\n  Departamento creado correctamente.\n";
}

void InterfazConsola::listarDepartamentos() const {
	mostrarTitulo("Departamentos y puestos");
	
	const Lista<Departamento>& lista = departamentos.getDepartamentos();
	
	if (lista.estaVacia()) {
		cout << "  No hay departamentos registrados.\n";
		return;
	}
	
	for (Nodo<Departamento>* nodo = lista.primero();
	nodo != nullptr;
	nodo = nodo->getSiguiente()) {
		
		const Departamento* d = nodo->getDato();
		
		cout << "\n  [" << d->getCodigo() << "] " << d->getNombre()
			<< "  (" << empleados.contarPorDepartamento(d->getCodigo())
			<< " empleado(s))\n";
		
		const Lista<Puesto>& puestos = d->getPuestos();
		
		if (puestos.estaVacia()) {
			cout << "      (sin puestos)\n";
		}
		
		for (Nodo<Puesto>* np = puestos.primero();
		np != nullptr;
		np = np->getSiguiente()) {
			
			cout << "      - " << np->getDato()->getCodigo()
				<< ": " << np->getDato()->getNombre() << "\n";
		}
	}
}

void InterfazConsola::agregarPuesto() {
	mostrarTitulo("Agregar puesto");
	
	string codigoDepartamento = EntradaConsola::leerTexto("Codigo del departamento: ");
	string codigoPuesto = EntradaConsola::leerTexto("Codigo del puesto: ");
	string nombrePuesto = EntradaConsola::leerTexto("Nombre del puesto: ");
	
	departamentos.agregarPuesto(codigoDepartamento, codigoPuesto, nombrePuesto);
	cout << "\n  Puesto agregado correctamente.\n";
}

void InterfazConsola::eliminarPuesto() {
	mostrarTitulo("Eliminar puesto");
	
	string codigoDepartamento = EntradaConsola::leerTexto("Codigo del departamento: ");
	string codigoPuesto = EntradaConsola::leerTexto("Codigo del puesto: ");
	
	if (!EntradaConsola::confirmar("Seguro que desea eliminar el puesto?")) {
		cout << "  Operacion cancelada.\n";
		return;
	}
	
	departamentos.eliminarPuesto(codigoDepartamento, codigoPuesto);
	empleados.desasignarPuesto(codigoDepartamento, codigoPuesto);
	
	cout << "\n  Puesto eliminado correctamente.\n";
}

void InterfazConsola::eliminarDepartamento() {
	mostrarTitulo("Eliminar departamento");
	
	string codigo = EntradaConsola::leerTexto("Codigo del departamento: ");
	const Departamento* d = departamentos.buscar(codigo);
	
	if (d == nullptr) {
		throw invalid_argument(
							   "No existe un departamento con el codigo " + codigo + ".");
	}
	
	int asignados = empleados.contarPorDepartamento(codigo);
	
	cout << "\n  Departamento: " << d->getNombre()
		<< "\n  Empleados asignados que quedaran sin departamento: "
		<< asignados << "\n";
	
	if (!EntradaConsola::confirmar("\nSeguro que desea eliminarlo junto con sus puestos?")) {
		cout << "  Operacion cancelada.\n";
		return;
	}
	
	planilla.desvincularDepartamento(codigo);
	empleados.desasignarDepartamento(codigo);
	departamentos.eliminar(codigo);
	
	cout << "\n  Departamento eliminado correctamente.\n";
}



void InterfazConsola::generarComprobanteIndividual() {
	mostrarTitulo("Generar comprobante");
	
	Empleado* e = solicitarEmpleadoExistente();
	string periodo = EntradaConsola::leerPeriodo("Periodo (AAAA-MM): ");
	
	const ComprobantePago* comprobante =
		planilla.generarComprobante(e->getIdentificacion(), periodo);
	
	mostrarComprobante(comprobante);
}

void InterfazConsola::generarPlanillaPeriodo() {
	mostrarTitulo("Generar planilla del periodo");
	
	if (empleados.getEmpleados().estaVacia()) {
		throw logic_error("No hay empleados registrados.");
	}
	
	string periodo = EntradaConsola::leerPeriodo("Periodo (AAAA-MM): ");
	int generados = planilla.generarPlanilla(periodo);
	
	cout << "\n  Comprobantes generados: " << generados << "\n";
	
	if (generados == 0) {
		cout << "  (Todos los empleados ya tenian comprobante en ese periodo.)\n";
	}
}

void InterfazConsola::listarComprobantes() const {
	mostrarTitulo("Comprobantes emitidos");
	
	const Lista<ComprobantePago>& lista = planilla.getComprobantes();
	
	if (lista.estaVacia()) {
		cout << "  No hay comprobantes emitidos.\n";
		return;
	}
	
	cout << left
						<< setw(8) << "No."
						<< setw(10) << "Periodo"
						<< setw(14) << "Empleado"
						<< setw(14) << "Neto"
						<< setw(11) << "Estado"
						<< "Nombre\n";
	
	for (Nodo<ComprobantePago>* nodo = lista.primero();
	nodo != nullptr;
	nodo = nodo->getSiguiente()) {
		
		const ComprobantePago* c = nodo->getDato();
		
		cout << left
			<< setw(8) << c->getNumero()
			<< setw(10) << c->getPeriodo()
			<< setw(14) << c->getIdEmpleado()
			<< setw(14) << formatearMonto(c->getDesglose().salarioNeto)
			<< setw(11) << (c->estaPagado() ? "Pagado" : "Pendiente")
			<< c->getNombreEmpleado() << "\n";
	}
}

void InterfazConsola::mostrarComprobante(const ComprobantePago* c) const {
	const DesglosePago& d = c->getDesglose();
	
	cout << "\n  ------------------------------------------"
		<< "\n  COMPROBANTE DE PAGO No. " << c->getNumero()
		<< "\n  ------------------------------------------"
		<< "\n  Periodo:         " << c->getPeriodo()
		<< "\n  Fecha emision:   " << c->getFechaEmision()
		<< "\n  Estado:          "
		<< (c->estaPagado() ? "Pagado el " + c->getFechaPago() : "Pendiente de pago")
		<< "\n  Empleado:        " << c->getNombreEmpleado()
		<< " (" << c->getIdEmpleado() << ")"
		<< (c->getEmpleado() == nullptr ? "  [ya no esta en el expediente]" : "")
		<< "\n  Tipo:            " << c->getTipoEmpleado()
		<< "\n  Departamento:    "
		<< (c->getCodigoDepartamento().empty()
			? "Sin asignar"
			: c->getCodigoDepartamento() + " - " + c->getNombreDepartamento())
		<< (!c->getCodigoDepartamento().empty() && c->getDepartamento() == nullptr
			? "  [ya no existe]" : "")
		<< "\n"
		<< "\n  Salario base:             " << formatearMonto(d.salarioBase)
		<< "\n  Horas extra:              " << formatearMonto(d.pagoHorasExtra)
		<< "\n  Bonificacion nocturna:    " << formatearMonto(d.bonificacionNocturna)
		<< "\n  Bonificacion guardias:    " << formatearMonto(d.bonificacionGuardias)
		<< "\n  Bonificacion del puesto:  " << formatearMonto(d.bonificacionPuesto)
		<< "\n  Salario bruto:            " << formatearMonto(d.salarioBruto)
		<< "\n  Deduccion de ley:         " << formatearMonto(d.deduccionLegal)
		<< "\n  SALARIO NETO:             " << formatearMonto(d.salarioNeto)
		<< "\n  ------------------------------------------\n";
}

void InterfazConsola::verComprobante() {
	mostrarTitulo("Ver comprobante");
	
	int numero = EntradaConsola::leerEntero("Numero de comprobante: ", 1);
	const ComprobantePago* comprobante = planilla.buscarComprobante(numero);
	
	if (comprobante == nullptr) {
		throw invalid_argument(
							   "No existe el comprobante numero " + to_string(numero) + ".");
	}
	
	mostrarComprobante(comprobante);
}

void InterfazConsola::procesarPagoIndividual() {
	mostrarTitulo("Procesar pago");
	
	int numero = EntradaConsola::leerEntero("Numero de comprobante: ", 1);
	const ComprobantePago* comprobante = planilla.buscarComprobante(numero);
	
	if (comprobante == nullptr) {
		throw invalid_argument(
							   "No existe el comprobante numero " + to_string(numero) + ".");
	}
	
	mostrarComprobante(comprobante);
	
	if (!EntradaConsola::confirmar("\nConfirma el pago de este comprobante?")) {
		cout << "  Operacion cancelada.\n";
		return;
	}
	
	planilla.procesarPago(numero);
	cout << "\n  Pago procesado correctamente.\n";
}

void InterfazConsola::procesarPagosDelPeriodo() {
	mostrarTitulo("Procesar pagos del periodo");
	
	string periodo = EntradaConsola::leerPeriodo("Periodo (AAAA-MM): ");
	
	if (!EntradaConsola::confirmar("Confirma el pago de todos los comprobantes pendientes?")) {
		cout << "  Operacion cancelada.\n";
		return;
	}
	
	int pagados = planilla.procesarPagosPeriodo(periodo);
	cout << "\n  Comprobantes pagados: " << pagados << "\n";
}

void InterfazConsola::mostrarResumenPeriodo() {
	mostrarTitulo("Resumen del periodo");
	
	string periodo = EntradaConsola::leerPeriodo("Periodo (AAAA-MM): ");
	int cantidad = planilla.contarComprobantes(periodo);
	
	if (cantidad == 0) {
		cout << "  No hay comprobantes en el periodo " << periodo << ".\n";
		return;
	}
	
	cout << "\n  Periodo:                " << periodo
		<< "\n  Comprobantes emitidos:  " << cantidad
		<< "\n  Total salario bruto:    " << formatearMonto(planilla.calcularTotalBruto(periodo))
		<< "\n  Total deducciones:      " << formatearMonto(planilla.calcularTotalDeducciones(periodo))
		<< "\n  Total salario neto:     " << formatearMonto(planilla.calcularTotalNeto(periodo))
		<< "\n";
}
