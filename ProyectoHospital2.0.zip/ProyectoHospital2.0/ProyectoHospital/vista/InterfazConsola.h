#ifndef INTERFAZCONSOLA_H
#define INTERFAZCONSOLA_H

#include "controladores/ControladorDepartamentos.h"
#include "controladores/ControladorEmpleados.h"
#include "controladores/ServicioPlanilla.h"
#include "modelo/ComprobantePago.h"
#include "modelo/Empleado.h"
#include "modelo/FabricaEmpleado.h"

class InterfazConsola {
private:
	ControladorEmpleados& empleados;
	ControladorDepartamentos& departamentos;
	ServicioPlanilla& planilla;
	const FabricaEmpleado& fabrica;
	
	void menuEmpleados();
	void menuDepartamentos();
	void menuPlanilla();
	
	void registrarEmpleado();
	void listarEmpleados() const;
	void verDetalleEmpleado();
	void modificarEmpleado();
	void asignarPuestoEmpleado();
	void eliminarEmpleado();
	
	void crearDepartamento();
	void listarDepartamentos() const;
	void agregarPuesto();
	void eliminarPuesto();
	void eliminarDepartamento();
	
	void generarComprobanteIndividual();
	void generarPlanillaPeriodo();
	void listarComprobantes() const;
	void verComprobante();
	void procesarPagoIndividual();
	void procesarPagosDelPeriodo();
	void mostrarResumenPeriodo();
	
	void mostrarEmpleado(const Empleado* empleado) const;
	void mostrarComprobante(const ComprobantePago* comprobante) const;
	Empleado* solicitarEmpleadoExistente();
	
public:
	InterfazConsola(
					ControladorEmpleados& empleados,
					ControladorDepartamentos& departamentos,
					ServicioPlanilla& planilla,
					const FabricaEmpleado& fabrica);
	
	InterfazConsola(const InterfazConsola&) = delete;
	InterfazConsola& operator=(const InterfazConsola&) = delete;
	
	void ejecutar();
};

#endif
