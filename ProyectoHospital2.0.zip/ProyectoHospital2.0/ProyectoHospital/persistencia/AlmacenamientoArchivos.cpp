#include "persistencia/AlmacenamientoArchivos.h"
#include <cstdio>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <stdexcept>
#include <vector>

using namespace std;

namespace {
	
	const char SEPARADOR = '|';
	
	vector<string> dividir(const string& linea) {
		vector<string> campos;
		string actual;
		
		for (char c : linea) {
			if (c == SEPARADOR) {
				campos.push_back(actual);
				actual.clear();
			} else {
				actual += c;
			}
		}
		
		campos.push_back(actual);
		return campos;
	}
	
	string limpiarCampo(const string& texto) {
		string resultado = texto;
		
		for (char& c : resultado) {
			if (c == SEPARADOR) {
				c = '/';
			} else if (c == '\n' || c == '\r') {
				c = ' ';
			}
		}
		
		return resultado;
	}
	
	string aTexto(double valor) {
		ostringstream flujo;
		flujo << setprecision(15) << valor;
		return flujo.str();
	}
	
	double aDecimal(const string& texto, const string& campo) {
		istringstream flujo(texto);
		double valor = 0.0;
		flujo >> valor;
		
		if (flujo.fail()) {
			throw invalid_argument(
								   "Valor decimal invalido en " + campo + ": '" + texto + "'.");
		}
		
		flujo >> ws;
		
		if (!flujo.eof()) {
			throw invalid_argument(
								   "Valor decimal invalido en " + campo + ": '" + texto + "'.");
		}
		
		return valor;
	}
	
	int aEntero(const string& texto, const string& campo) {
		size_t posicion = 0;
		int valor = 0;
		
		try {
			valor = stoi(texto, &posicion);
		} catch (const exception&) {
			throw invalid_argument(
								   "Valor entero invalido en " + campo + ": '" + texto + "'.");
		}
		
		if (posicion != texto.size()) {
			throw invalid_argument(
								   "Valor entero invalido en " + campo + ": '" + texto + "'.");
		}
		
		return valor;
	}
	
	bool aBooleano(const string& texto, const string& campo) {
		if (texto == "1") {
			return true;
		}
		
		if (texto == "0") {
			return false;
		}
		
		throw invalid_argument(
							   "Valor booleano invalido en " + campo + ": '" + texto + "'.");
	}
	
	void exigirCampos(const vector<string>& campos, size_t esperados) {
		if (campos.size() != esperados) {
			throw invalid_argument(
								   "Se esperaban " + to_string(esperados) +
								   " campos y se encontraron " +
								   to_string(campos.size()) + ".");
		}
	}
	
	void escribirArchivo(const string& ruta, const string& contenido) {
		const string temporal = ruta + ".tmp";
		
		{
			ofstream salida(temporal, ios::trunc);
			
			if (!salida.is_open()) {
				throw runtime_error(
									"No se pudo abrir el archivo " + temporal);
			}
			
			salida << contenido;
			salida.flush();
			
			if (!salida) {
				throw runtime_error(
									"Error al escribir el archivo " + temporal);
			}
		}
		
		remove(ruta.c_str());
		
		if (rename(temporal.c_str(), ruta.c_str()) != 0) {
			throw runtime_error(
								"No se pudo actualizar " + ruta);
		}
	}
	
}

AlmacenamientoArchivos::AlmacenamientoArchivos(
											   const FabricaEmpleado& fabrica,
											   const string& rutaEmpleados,
											   const string& rutaDepartamentos,
											   const string& rutaPlanilla)
	
	: fabrica(fabrica),
	rutaEmpleados(rutaEmpleados),
	rutaDepartamentos(rutaDepartamentos),
	rutaPlanilla(rutaPlanilla) {}



void AlmacenamientoArchivos::cargarEmpleados(Lista<Empleado>& destino) {
	destino.limpiar();
	
	ifstream archivo(rutaEmpleados);
	
	if (!archivo.is_open()) {
		return;
	}
	
	string linea;
	int numeroLinea = 0;
	
	while (getline(archivo, linea)) {
		++numeroLinea;
		
		if (!linea.empty() && linea.back() == '\r') {
			linea.pop_back();
		}
		
		if (linea.empty() || linea[0] == '#') {
			continue;
		}
		
		try {
			vector<string> c = dividir(linea);
			exigirCampos(c, 15);
			
			DatosEmpleado datos;
			datos.tipo = c[0];
			datos.identificacion = c[1];
			datos.nombre = c[2];
			datos.salarioBase = aDecimal(c[3], "salario base");
			datos.horasExtra = aDecimal(c[4], "horas extra");
			datos.valorHoraExtra = aDecimal(c[5], "valor hora extra");
			datos.turnosNocturnos = aEntero(c[6], "turnos nocturnos");
			datos.bonificacionTurnoNocturno = aDecimal(c[7], "bonificacion nocturna");
			datos.guardias = aEntero(c[8], "guardias");
			datos.bonificacionGuardia = aDecimal(c[9], "bonificacion guardia");
			datos.tasaDeduccionLegal = aDecimal(c[10], "tasa de deduccion");
			datos.idDepartamento = c[11];
			datos.codigoPuesto = c[12];
			datos.detallePuesto = c[13];
			datos.bonificacionPuesto = aDecimal(c[14], "bonificacion del puesto");
			
			destino.agregar(fabrica.crear(datos));
		} catch (const exception& e) {
			throw runtime_error(
								rutaEmpleados + ", linea " +
								to_string(numeroLinea) + ": " + e.what());
		}
	}
}

void AlmacenamientoArchivos::guardarEmpleados(const Lista<Empleado>& origen) {
	ostringstream contenido;
	
	for (Nodo<Empleado>* nodo = origen.primero();
	nodo != nullptr;
	nodo = nodo->getSiguiente()) {
		
		const Empleado* e = nodo->getDato();
		
		contenido
			<< limpiarCampo(e->obtenerTipo()) << SEPARADOR
			<< limpiarCampo(e->getIdentificacion()) << SEPARADOR
			<< limpiarCampo(e->getNombre()) << SEPARADOR
			<< aTexto(e->getSalarioBase()) << SEPARADOR
			<< aTexto(e->getHorasExtra()) << SEPARADOR
			<< aTexto(e->getValorHoraExtra()) << SEPARADOR
			<< e->getTurnosNocturnos() << SEPARADOR
			<< aTexto(e->getBonificacionTurnoNocturno()) << SEPARADOR
			<< e->getGuardias() << SEPARADOR
			<< aTexto(e->getBonificacionGuardia()) << SEPARADOR
			<< aTexto(e->getTasaDeduccionLegal()) << SEPARADOR
			<< limpiarCampo(e->getIdDepartamento()) << SEPARADOR
			<< limpiarCampo(e->getCodigoPuesto()) << SEPARADOR
			<< limpiarCampo(e->obtenerDetallePuesto()) << SEPARADOR
			<< aTexto(e->calcularBonificacionPuesto())
			<< '\n';
	}
	
	escribirArchivo(rutaEmpleados, contenido.str());
}



void AlmacenamientoArchivos::cargarDepartamentos(
												 Lista<Departamento>& destino) {
	
	destino.limpiar();
	
	ifstream archivo(rutaDepartamentos);
	
	if (!archivo.is_open()) {
		return;
	}
	
	string linea;
	int numeroLinea = 0;
	
	while (getline(archivo, linea)) {
		++numeroLinea;
		
		if (!linea.empty() && linea.back() == '\r') {
			linea.pop_back();
		}
		
		if (linea.empty() || linea[0] == '#') {
			continue;
		}
		
		try {
			vector<string> c = dividir(linea);
			
			if (c[0] == "D") {
				exigirCampos(c, 3);
				destino.agregar(new Departamento(c[1], c[2]));
			} else if (c[0] == "P") {
				exigirCampos(c, 4);
				
				Departamento* departamento = nullptr;
				
				for (Nodo<Departamento>* nodo = destino.primero();
				nodo != nullptr;
				nodo = nodo->getSiguiente()) {
					
					if (nodo->getDato()->getCodigo() == c[1]) {
						departamento = nodo->getDato();
						break;
					}
				}
				
				if (departamento == nullptr) {
					throw invalid_argument(
										   "El puesto " + c[2] + " hace referencia a un "
										   "departamento inexistente: " + c[1]);
				}
				
				departamento->agregarPuesto(c[2], c[3]);
			} else {
				throw invalid_argument(
									   "Tipo de registro desconocido: '" + c[0] + "'.");
			}
		} catch (const exception& e) {
			throw runtime_error(
								rutaDepartamentos + ", linea " +
								to_string(numeroLinea) + ": " + e.what());
		}
	}
}

void AlmacenamientoArchivos::guardarDepartamentos(
												  const Lista<Departamento>& origen) {
	
	ostringstream contenido;
	
	for (Nodo<Departamento>* nodo = origen.primero();
	nodo != nullptr;
	nodo = nodo->getSiguiente()) {
		
		const Departamento* d = nodo->getDato();
		
		contenido << "D" << SEPARADOR
			<< limpiarCampo(d->getCodigo()) << SEPARADOR
			<< limpiarCampo(d->getNombre()) << '\n';
		
		const Lista<Puesto>& puestos = d->getPuestos();
		
		for (Nodo<Puesto>* np = puestos.primero();
		np != nullptr;
		np = np->getSiguiente()) {
			
			contenido << "P" << SEPARADOR
				<< limpiarCampo(d->getCodigo()) << SEPARADOR
				<< limpiarCampo(np->getDato()->getCodigo()) << SEPARADOR
				<< limpiarCampo(np->getDato()->getNombre()) << '\n';
		}
	}
	
	escribirArchivo(rutaDepartamentos, contenido.str());
}



void AlmacenamientoArchivos::cargarComprobantes(
												Lista<ComprobantePago>& destino,
												const Lista<Empleado>& empleados,
												const Lista<Departamento>& departamentos) {
	
	destino.limpiar();
	
	ifstream archivo(rutaPlanilla);
	
	if (!archivo.is_open()) {
		return;
	}
	
	string linea;
	int numeroLinea = 0;
	
	while (getline(archivo, linea)) {
		++numeroLinea;
		
		if (!linea.empty() && linea.back() == '\r') {
			linea.pop_back();
		}
		
		if (linea.empty() || linea[0] == '#') {
			continue;
		}
		
		try {
			vector<string> c = dividir(linea);
			exigirCampos(c, 18);
			
			DesglosePago desglose;
			desglose.salarioBase = aDecimal(c[10], "salario base");
			desglose.pagoHorasExtra = aDecimal(c[11], "pago horas extra");
			desglose.bonificacionNocturna = aDecimal(c[12], "bonificacion nocturna");
			desglose.bonificacionGuardias = aDecimal(c[13], "bonificacion guardias");
			desglose.bonificacionPuesto = aDecimal(c[14], "bonificacion puesto");
			desglose.salarioBruto = aDecimal(c[15], "salario bruto");
			desglose.deduccionLegal = aDecimal(c[16], "deduccion legal");
			desglose.salarioNeto = aDecimal(c[17], "salario neto");
			
			const Empleado* empleado = nullptr;
			
			for (Nodo<Empleado>* nodo = empleados.primero();
			nodo != nullptr;
			nodo = nodo->getSiguiente()) {
				
				if (nodo->getDato()->getIdentificacion() == c[5]) {
					empleado = nodo->getDato();
					break;
				}
			}
			
			const Departamento* departamento = nullptr;
			
			if (!c[8].empty()) {
				for (Nodo<Departamento>* nodo = departamentos.primero();
				nodo != nullptr;
				nodo = nodo->getSiguiente()) {
					
					if (nodo->getDato()->getCodigo() == c[8]) {
						departamento = nodo->getDato();
						break;
					}
				}
			}
			
			destino.agregar(new ComprobantePago(
												aEntero(c[0], "numero de comprobante"),
												c[1],
												c[2],
												aBooleano(c[3], "estado de pago"),
												c[4],
												c[5],
												c[6],
												c[7],
												c[8],
												c[9],
												desglose,
												empleado,
												departamento));
		} catch (const exception& e) {
			throw runtime_error(
								rutaPlanilla + ", linea " +
								to_string(numeroLinea) + ": " + e.what());
		}
	}
}

void AlmacenamientoArchivos::guardarComprobantes(
												 const Lista<ComprobantePago>& origen) {
	
	ostringstream contenido;
	
	for (Nodo<ComprobantePago>* nodo = origen.primero();
	nodo != nullptr;
	nodo = nodo->getSiguiente()) {
		
		const ComprobantePago* p = nodo->getDato();
		const DesglosePago& d = p->getDesglose();
		
		contenido
			<< p->getNumero() << SEPARADOR
			<< limpiarCampo(p->getPeriodo()) << SEPARADOR
			<< limpiarCampo(p->getFechaEmision()) << SEPARADOR
			<< (p->estaPagado() ? "1" : "0") << SEPARADOR
			<< limpiarCampo(p->getFechaPago()) << SEPARADOR
			<< limpiarCampo(p->getIdEmpleado()) << SEPARADOR
			<< limpiarCampo(p->getNombreEmpleado()) << SEPARADOR
			<< limpiarCampo(p->getTipoEmpleado()) << SEPARADOR
			<< limpiarCampo(p->getCodigoDepartamento()) << SEPARADOR
			<< limpiarCampo(p->getNombreDepartamento()) << SEPARADOR
			<< aTexto(d.salarioBase) << SEPARADOR
			<< aTexto(d.pagoHorasExtra) << SEPARADOR
			<< aTexto(d.bonificacionNocturna) << SEPARADOR
			<< aTexto(d.bonificacionGuardias) << SEPARADOR
			<< aTexto(d.bonificacionPuesto) << SEPARADOR
			<< aTexto(d.salarioBruto) << SEPARADOR
			<< aTexto(d.deduccionLegal) << SEPARADOR
			<< aTexto(d.salarioNeto)
			<< '\n';
	}
	
	escribirArchivo(rutaPlanilla, contenido.str());
}
