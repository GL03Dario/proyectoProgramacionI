#ifndef IALMACENAMIENTODEPARTAMENTOS_H
#define IALMACENAMIENTODEPARTAMENTOS_H

#include "colecciones/Lista.h"
#include "modelo/Departamento.h"

class IAlmacenamientoDepartamentos {
public:
	virtual ~IAlmacenamientoDepartamentos() = default;
	
	virtual void cargarDepartamentos(Lista<Departamento>& destino) = 0;
	
	virtual void guardarDepartamentos(const Lista<Departamento>& origen) = 0;
};

#endif
