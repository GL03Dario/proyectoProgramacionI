#ifndef ALMACENAMIENTOARCHIVOS_H
#define ALMACENAMIENTOARCHIVOS_H

#include "modelo/FabricaEmpleado.h"
#include "persistencia/IAlmacenamientoComprobantes.h"
#include "persistencia/IAlmacenamientoDepartamentos.h"
#include "persistencia/IAlmacenamientoEmpleados.h"
#include <string>

class AlmacenamientoArchivos : public IAlmacenamientoEmpleados,
	public IAlmacenamientoDepartamentos,
	public IAlmacenamientoComprobantes {
	private:
		const FabricaEmpleado& fabrica;
		std::string rutaEmpleados;
		std::string rutaDepartamentos;
		std::string rutaPlanilla;
		
	public:
		explicit AlmacenamientoArchivos(
										const FabricaEmpleado& fabrica,
										const std::string& rutaEmpleados = "empleados.txt",
										const std::string& rutaDepartamentos = "departamentos.txt",
										const std::string& rutaPlanilla = "planilla.txt");
		
		void cargarEmpleados(Lista<Empleado>& destino) override;
		void guardarEmpleados(const Lista<Empleado>& origen) override;
		
		void cargarDepartamentos(Lista<Departamento>& destino) override;
		void guardarDepartamentos(const Lista<Departamento>& origen) override;
		
		void cargarComprobantes(
								Lista<ComprobantePago>& destino,
								const Lista<Empleado>& empleados,
								const Lista<Departamento>& departamentos) override;
		
		void guardarComprobantes(const Lista<ComprobantePago>& origen) override;
};
	
#endif
