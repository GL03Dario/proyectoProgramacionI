#ifndef IALMACENAMIENTOCOMPROBANTES_H
#define IALMACENAMIENTOCOMPROBANTES_H

#include "colecciones/Lista.h"
#include "modelo/ComprobantePago.h"
#include "modelo/Departamento.h"
#include "modelo/Empleado.h"

class IAlmacenamientoComprobantes {
public:
	virtual ~IAlmacenamientoComprobantes() = default;
	
	virtual void cargarComprobantes(
									Lista<ComprobantePago>& destino,
									const Lista<Empleado>& empleados,
									const Lista<Departamento>& departamentos) = 0;
	
	virtual void guardarComprobantes(
									 const Lista<ComprobantePago>& origen) = 0;
};

#endif
