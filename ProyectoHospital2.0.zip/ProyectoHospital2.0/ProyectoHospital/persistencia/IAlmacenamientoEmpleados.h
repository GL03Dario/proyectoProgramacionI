#ifndef IALMACENAMIENTOEMPLEADOS_H
#define IALMACENAMIENTOEMPLEADOS_H

#include "colecciones/Lista.h"
#include "modelo/Empleado.h"

class IAlmacenamientoEmpleados {
public:
	virtual ~IAlmacenamientoEmpleados() = default;
	
	virtual void cargarEmpleados(Lista<Empleado>& destino) = 0;
	
	virtual void guardarEmpleados(const Lista<Empleado>& origen) = 0;
};

#endif
