#include "controladores/ControladorEmpleados.h"
#include <stdexcept>

using namespace std;

ControladorEmpleados::ControladorEmpleados(
										   IAlmacenamientoEmpleados& almacenamiento,
										   const FabricaEmpleado& fabrica,
										   const ControladorDepartamentos& departamentos)
	
	: almacenamiento(almacenamiento),
	fabrica(fabrica),
	departamentos(departamentos) {
	
	this->almacenamiento.cargarEmpleados(empleados);
}

void ControladorEmpleados::validarAsignacion(
											 const string& idDepartamento,
											 const string& codigoPuesto) const {
	
	if (idDepartamento.empty()) {
		if (!codigoPuesto.empty()) {
			throw invalid_argument(
								   "No se puede asignar un puesto sin departamento.");
		}
		
		return;
	}
	
	if (departamentos.buscar(idDepartamento) == nullptr) {
		throw invalid_argument(
							   "No existe un departamento con el codigo " +
							   idDepartamento + ".");
	}
	
	if (!codigoPuesto.empty() &&
		!departamentos.existePuesto(idDepartamento, codigoPuesto)) {
		
		throw invalid_argument(
							   "No existe el puesto " + codigoPuesto +
							   " en el departamento " + idDepartamento + ".");
	}
}

Empleado* ControladorEmpleados::registrar(const DatosEmpleado& datos) {
	if (buscar(datos.identificacion) != nullptr) {
		throw invalid_argument(
							   "Ya existe un empleado con la identificacion " +
							   datos.identificacion + ".");
	}
	
	validarAsignacion(datos.idDepartamento, datos.codigoPuesto);
	
	Empleado* empleado = fabrica.crear(datos);
	empleados.agregar(empleado);
	guardar();
	
	return empleado;
}

Empleado* ControladorEmpleados::buscar(
									   const string& identificacion) const {
	
	for (Nodo<Empleado>* nodo = empleados.primero();
	nodo != nullptr;
	nodo = nodo->getSiguiente()) {
		
		if (nodo->getDato()->getIdentificacion() == identificacion) {
			return nodo->getDato();
		}
	}
	
	return nullptr;
}

void ControladorEmpleados::eliminar(const string& identificacion) {
	Empleado* empleado = buscar(identificacion);
	
	if (empleado == nullptr) {
		throw invalid_argument(
							   "No existe un empleado con la identificacion " +
							   identificacion + ".");
	}
	
	empleados.eliminar(empleado);
	guardar();
}

void ControladorEmpleados::asignarPuesto(
										 const string& identificacion,
										 const string& idDepartamento,
										 const string& codigoPuesto) {
	
	Empleado* empleado = buscar(identificacion);
	
	if (empleado == nullptr) {
		throw invalid_argument(
							   "No existe un empleado con la identificacion " +
							   identificacion + ".");
	}
	
	validarAsignacion(idDepartamento, codigoPuesto);
	
	empleado->setIdDepartamento(idDepartamento);
	empleado->setCodigoPuesto(codigoPuesto);
	guardar();
}

void ControladorEmpleados::desasignarDepartamento(
												  const string& idDepartamento) {
	
	bool huboCambios = false;
	
	for (Nodo<Empleado>* nodo = empleados.primero();
	nodo != nullptr;
	nodo = nodo->getSiguiente()) {
		
		Empleado* empleado = nodo->getDato();
		
		if (empleado->getIdDepartamento() == idDepartamento) {
			empleado->setIdDepartamento("");
			empleado->setCodigoPuesto("");
			huboCambios = true;
		}
	}
	
	if (huboCambios) {
		guardar();
	}
}

void ControladorEmpleados::desasignarPuesto(
											const string& idDepartamento,
											const string& codigoPuesto) {
	
	bool huboCambios = false;
	
	for (Nodo<Empleado>* nodo = empleados.primero();
	nodo != nullptr;
	nodo = nodo->getSiguiente()) {
		
		Empleado* empleado = nodo->getDato();
		
		if (empleado->getIdDepartamento() == idDepartamento &&
			empleado->getCodigoPuesto() == codigoPuesto) {
			
			empleado->setCodigoPuesto("");
			huboCambios = true;
		}
	}
	
	if (huboCambios) {
		guardar();
	}
}

int ControladorEmpleados::contarPorDepartamento(
												const string& idDepartamento) const {
	
	int cantidad = 0;
	
	for (Nodo<Empleado>* nodo = empleados.primero();
	nodo != nullptr;
	nodo = nodo->getSiguiente()) {
		
		if (nodo->getDato()->getIdDepartamento() == idDepartamento) {
			++cantidad;
		}
	}
	
	return cantidad;
}

const Lista<Empleado>& ControladorEmpleados::getEmpleados() const {
	return empleados;
}

void ControladorEmpleados::guardar() const {
	almacenamiento.guardarEmpleados(empleados);
}
