#include "controladores/ServicioPlanilla.h"
#include <cctype>
#include <ctime>
#include <stdexcept>

using namespace std;

ServicioPlanilla::ServicioPlanilla(
								   IAlmacenamientoComprobantes& almacenamiento,
								   const ControladorEmpleados& empleados,
								   const ControladorDepartamentos& departamentos)
	
	: almacenamiento(almacenamiento),
	empleados(empleados),
	departamentos(departamentos) {
	
	this->almacenamiento.cargarComprobantes(
											comprobantes,
											empleados.getEmpleados(),
											departamentos.getDepartamentos());
}

void ServicioPlanilla::validarPeriodo(const string& periodo) {
	bool valido = periodo.size() == 7 && periodo[4] == '-';
	
	for (size_t i = 0; valido && i < periodo.size(); ++i) {
		if (i != 4 &&
			!isdigit(static_cast<unsigned char>(periodo[i]))) {
			
			valido = false;
		}
	}
	
	if (valido) {
		int mes = stoi(periodo.substr(5, 2));
		valido = mes >= 1 && mes <= 12;
	}
	
	if (!valido) {
		throw invalid_argument(
							   "El periodo debe tener el formato AAAA-MM (ejemplo: 2026-11).");
	}
}

string ServicioPlanilla::fechaActual() {
	time_t ahora = time(nullptr);
	tm* local = localtime(&ahora);
	
	if (local == nullptr) {
		return "0000-00-00";
	}
	
	char buffer[16];
	strftime(buffer, sizeof(buffer), "%Y-%m-%d", local);
	
	return buffer;
}

int ServicioPlanilla::siguienteNumero() const {
	int mayor = 0;
	
	for (Nodo<ComprobantePago>* nodo = comprobantes.primero();
	nodo != nullptr;
	nodo = nodo->getSiguiente()) {
		
		if (nodo->getDato()->getNumero() > mayor) {
			mayor = nodo->getDato()->getNumero();
		}
	}
	
	return mayor + 1;
}

bool ServicioPlanilla::existeComprobante(
										 const string& idEmpleado, const string& periodo) const {
	
	for (Nodo<ComprobantePago>* nodo = comprobantes.primero();
	nodo != nullptr;
	nodo = nodo->getSiguiente()) {
		
		ComprobantePago* c = nodo->getDato();
		
		if (c->getIdEmpleado() == idEmpleado &&
			c->getPeriodo() == periodo) {
			return true;
		}
	}
	
	return false;
}

ComprobantePago* ServicioPlanilla::emitir(
										  const Empleado* empleado, const string& periodo) {
	
	const Departamento* departamento = nullptr;
	
	if (!empleado->getIdDepartamento().empty()) {
		departamento = departamentos.buscar(empleado->getIdDepartamento());
	}
	
	ComprobantePago* comprobante = new ComprobantePago(
													   siguienteNumero(),
													   periodo,
													   fechaActual(),
													   empleado,
													   departamento);
	
	comprobantes.agregar(comprobante);
	
	return comprobante;
}

ComprobantePago* ServicioPlanilla::generarComprobante(
													  const string& idEmpleado, const string& periodo) {
	
	validarPeriodo(periodo);
	
	const Empleado* empleado = empleados.buscar(idEmpleado);
	
	if (empleado == nullptr) {
		throw invalid_argument(
							   "No existe un empleado con la identificacion " +
							   idEmpleado + ".");
	}
	
	if (existeComprobante(idEmpleado, periodo)) {
		throw logic_error(
						  "El empleado " + idEmpleado +
						  " ya tiene un comprobante en el periodo " + periodo + ".");
	}
	
	ComprobantePago* comprobante = emitir(empleado, periodo);
	guardar();
	
	return comprobante;
}

int ServicioPlanilla::generarPlanilla(const string& periodo) {
	validarPeriodo(periodo);
	
	int generados = 0;
	
	for (Nodo<Empleado>* nodo = empleados.getEmpleados().primero();
	nodo != nullptr;
	nodo = nodo->getSiguiente()) {
		
		const Empleado* empleado = nodo->getDato();
		
		if (!existeComprobante(empleado->getIdentificacion(), periodo)) {
			emitir(empleado, periodo);
			++generados;
		}
	}
	
	if (generados > 0) {
		guardar();
	}
	
	return generados;
}

void ServicioPlanilla::procesarPago(int numeroComprobante) {
	ComprobantePago* comprobante = buscarComprobante(numeroComprobante);
	
	if (comprobante == nullptr) {
		throw invalid_argument(
							   "No existe el comprobante numero " +
							   to_string(numeroComprobante) + ".");
	}
	
	comprobante->marcarPagado(fechaActual());
	guardar();
}

int ServicioPlanilla::procesarPagosPeriodo(const string& periodo) {
	validarPeriodo(periodo);
	
	int pagados = 0;
	const string fecha = fechaActual();
	
	for (Nodo<ComprobantePago>* nodo = comprobantes.primero();
	nodo != nullptr;
	nodo = nodo->getSiguiente()) {
		
		ComprobantePago* comprobante = nodo->getDato();
		
		if (comprobante->getPeriodo() == periodo &&
			!comprobante->estaPagado()) {
			
			comprobante->marcarPagado(fecha);
			++pagados;
		}
	}
	
	if (pagados > 0) {
		guardar();
	}
	
	return pagados;
}

ComprobantePago* ServicioPlanilla::buscarComprobante(int numero) const {
	for (Nodo<ComprobantePago>* nodo = comprobantes.primero();
	nodo != nullptr;
	nodo = nodo->getSiguiente()) {
		
		if (nodo->getDato()->getNumero() == numero) {
			return nodo->getDato();
		}
	}
	
	return nullptr;
}

int ServicioPlanilla::contarComprobantes(const string& periodo) const {
	int cantidad = 0;
	
	for (Nodo<ComprobantePago>* nodo = comprobantes.primero();
	nodo != nullptr;
	nodo = nodo->getSiguiente()) {
		
		if (nodo->getDato()->getPeriodo() == periodo) {
			++cantidad;
		}
	}
	
	return cantidad;
}

double ServicioPlanilla::calcularTotalBruto(
											const string& periodo) const {
	
	double total = 0.0;
	
	for (Nodo<ComprobantePago>* nodo = comprobantes.primero();
	nodo != nullptr;
	nodo = nodo->getSiguiente()) {
		
		if (nodo->getDato()->getPeriodo() == periodo) {
			total += nodo->getDato()->getDesglose().salarioBruto;
		}
	}
	
	return total;
}

double ServicioPlanilla::calcularTotalDeducciones(
												  const string& periodo) const {
	
	double total = 0.0;
	
	for (Nodo<ComprobantePago>* nodo = comprobantes.primero();
	nodo != nullptr;
	nodo = nodo->getSiguiente()) {
		
		if (nodo->getDato()->getPeriodo() == periodo) {
			total += nodo->getDato()->getDesglose().deduccionLegal;
		}
	}
	
	return total;
}

double ServicioPlanilla::calcularTotalNeto(
										   const string& periodo) const {
	
	double total = 0.0;
	
	for (Nodo<ComprobantePago>* nodo = comprobantes.primero();
	nodo != nullptr;
	nodo = nodo->getSiguiente()) {
		
		if (nodo->getDato()->getPeriodo() == periodo) {
			total += nodo->getDato()->getDesglose().salarioNeto;
		}
	}
	
	return total;
}

void ServicioPlanilla::desvincularEmpleado(const string& idEmpleado) {
	for (Nodo<ComprobantePago>* nodo = comprobantes.primero();
	nodo != nullptr;
	nodo = nodo->getSiguiente()) {
		
		if (nodo->getDato()->getIdEmpleado() == idEmpleado) {
			nodo->getDato()->desvincularEmpleado();
		}
	}
}

void ServicioPlanilla::desvincularDepartamento(
											   const string& codigoDepartamento) {
	
	for (Nodo<ComprobantePago>* nodo = comprobantes.primero();
	nodo != nullptr;
	nodo = nodo->getSiguiente()) {
		
		if (nodo->getDato()->getCodigoDepartamento() == codigoDepartamento) {
			nodo->getDato()->desvincularDepartamento();
		}
	}
}

const Lista<ComprobantePago>& ServicioPlanilla::getComprobantes() const {
	return comprobantes;
}

void ServicioPlanilla::guardar() const {
	almacenamiento.guardarComprobantes(comprobantes);
}
