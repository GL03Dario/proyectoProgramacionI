#ifndef CONTROLADORDEPARTAMENTOS_H
#define CONTROLADORDEPARTAMENTOS_H

#include "colecciones/Lista.h"
#include "modelo/Departamento.h"
#include "persistencia/IAlmacenamientoDepartamentos.h"
#include <string>

class ControladorDepartamentos {
private:
	IAlmacenamientoDepartamentos& almacenamiento;
	Lista<Departamento> departamentos;
	
public:
	explicit ControladorDepartamentos(
									  IAlmacenamientoDepartamentos& almacenamiento);
	
	ControladorDepartamentos(const ControladorDepartamentos&) = delete;
	ControladorDepartamentos& operator=(
										const ControladorDepartamentos&) = delete;
	
	Departamento* crear(
						const std::string& codigo, const std::string& nombre);
	
	Departamento* buscar(const std::string& codigo) const;
	
	void renombrar(
				   const std::string& codigo, const std::string& nuevoNombre);
	
	void eliminar(const std::string& codigo);
	
	void agregarPuesto(
					   const std::string& codigoDepartamento,
					   const std::string& codigoPuesto,
					   const std::string& nombrePuesto);
	
	void eliminarPuesto(
						const std::string& codigoDepartamento,
						const std::string& codigoPuesto);
	
	bool existePuesto(
					  const std::string& codigoDepartamento,
					  const std::string& codigoPuesto) const;
	
	const Lista<Departamento>& getDepartamentos() const;
	
	void guardar() const;
};

#endif
