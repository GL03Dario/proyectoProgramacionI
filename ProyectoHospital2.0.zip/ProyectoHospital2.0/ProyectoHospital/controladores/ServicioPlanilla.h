#ifndef SERVICIOPLANILLA_H
#define SERVICIOPLANILLA_H

#include "colecciones/Lista.h"
#include "controladores/ControladorDepartamentos.h"
#include "controladores/ControladorEmpleados.h"
#include "modelo/ComprobantePago.h"
#include "persistencia/IAlmacenamientoComprobantes.h"
#include <string>

class ServicioPlanilla {
private:
	IAlmacenamientoComprobantes& almacenamiento;
	const ControladorEmpleados& empleados;
	const ControladorDepartamentos& departamentos;
	Lista<ComprobantePago> comprobantes;
	
	int siguienteNumero() const;
	bool existeComprobante(
						   const std::string& idEmpleado, const std::string& periodo) const;
	
	ComprobantePago* emitir(
							const Empleado* empleado, const std::string& periodo);
	
	static void validarPeriodo(const std::string& periodo);
	static std::string fechaActual();
	
public:
	ServicioPlanilla(
					 IAlmacenamientoComprobantes& almacenamiento,
					 const ControladorEmpleados& empleados,
					 const ControladorDepartamentos& departamentos);
	
	ServicioPlanilla(const ServicioPlanilla&) = delete;
	ServicioPlanilla& operator=(const ServicioPlanilla&) = delete;
	
	ComprobantePago* generarComprobante(
										const std::string& idEmpleado, const std::string& periodo);
	
	int generarPlanilla(const std::string& periodo);
	
	void procesarPago(int numeroComprobante);
	
	int procesarPagosPeriodo(const std::string& periodo);
	
	ComprobantePago* buscarComprobante(int numero) const;
	
	int contarComprobantes(const std::string& periodo) const;
	double calcularTotalBruto(const std::string& periodo) const;
	double calcularTotalDeducciones(const std::string& periodo) const;
	double calcularTotalNeto(const std::string& periodo) const;
	
	void desvincularEmpleado(const std::string& idEmpleado);
	void desvincularDepartamento(const std::string& codigoDepartamento);
	
	const Lista<ComprobantePago>& getComprobantes() const;
	
	void guardar() const;
};

#endif
