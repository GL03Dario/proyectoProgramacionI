#include "controladores/ControladorDepartamentos.h"
#include <stdexcept>

using namespace std;

ControladorDepartamentos::ControladorDepartamentos(
												   IAlmacenamientoDepartamentos& almacenamiento)
	: almacenamiento(almacenamiento) {
	
	this->almacenamiento.cargarDepartamentos(departamentos);
}

Departamento* ControladorDepartamentos::crear(
											  const string& codigo, const string& nombre) {
	
	if (buscar(codigo) != nullptr) {
		throw invalid_argument(
							   "Ya existe un departamento con el codigo " + codigo + ".");
	}
	
	Departamento* departamento = new Departamento(codigo, nombre);
	departamentos.agregar(departamento);
	guardar();
	
	return departamento;
}

Departamento* ControladorDepartamentos::buscar(
											   const string& codigo) const {
	
	for (Nodo<Departamento>* nodo = departamentos.primero();
	nodo != nullptr;
	nodo = nodo->getSiguiente()) {
		
		if (nodo->getDato()->getCodigo() == codigo) {
			return nodo->getDato();
		}
	}
	
	return nullptr;
}

void ControladorDepartamentos::renombrar(
										 const string& codigo, const string& nuevoNombre) {
	
	Departamento* departamento = buscar(codigo);
	
	if (departamento == nullptr) {
		throw invalid_argument(
							   "No existe un departamento con el codigo " + codigo + ".");
	}
	
	departamento->setNombre(nuevoNombre);
	guardar();
}

void ControladorDepartamentos::eliminar(const string& codigo) {
	Departamento* departamento = buscar(codigo);
	
	if (departamento == nullptr) {
		throw invalid_argument(
							   "No existe un departamento con el codigo " + codigo + ".");
	}
	
	departamentos.eliminar(departamento);
	guardar();
}

void ControladorDepartamentos::agregarPuesto(
											 const string& codigoDepartamento,
											 const string& codigoPuesto,
											 const string& nombrePuesto) {
	
	Departamento* departamento = buscar(codigoDepartamento);
	
	if (departamento == nullptr) {
		throw invalid_argument(
							   "No existe un departamento con el codigo " +
							   codigoDepartamento + ".");
	}
	
	departamento->agregarPuesto(codigoPuesto, nombrePuesto);
	guardar();
}

void ControladorDepartamentos::eliminarPuesto(
											  const string& codigoDepartamento,
											  const string& codigoPuesto) {
	
	Departamento* departamento = buscar(codigoDepartamento);
	
	if (departamento == nullptr) {
		throw invalid_argument(
							   "No existe un departamento con el codigo " +
							   codigoDepartamento + ".");
	}
	
	if (!departamento->eliminarPuesto(codigoPuesto)) {
		throw invalid_argument(
							   "No existe el puesto " + codigoPuesto +
							   " en el departamento " + codigoDepartamento + ".");
	}
	
	guardar();
}

bool ControladorDepartamentos::existePuesto(
											const string& codigoDepartamento,
											const string& codigoPuesto) const {
	
	const Departamento* departamento = buscar(codigoDepartamento);
	
	return departamento != nullptr &&
		departamento->existePuesto(codigoPuesto);
}

const Lista<Departamento>& ControladorDepartamentos::getDepartamentos() const {
	return departamentos;
}

void ControladorDepartamentos::guardar() const {
	almacenamiento.guardarDepartamentos(departamentos);
}
