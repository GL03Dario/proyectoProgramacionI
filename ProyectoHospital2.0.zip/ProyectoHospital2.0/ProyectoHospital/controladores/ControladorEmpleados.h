#ifndef CONTROLADOREMPLEADOS_H
#define CONTROLADOREMPLEADOS_H

#include "colecciones/Lista.h"
#include "controladores/ControladorDepartamentos.h"
#include "modelo/Empleado.h"
#include "modelo/FabricaEmpleado.h"
#include "persistencia/IAlmacenamientoEmpleados.h"
#include <string>

class ControladorEmpleados {
private:
	IAlmacenamientoEmpleados& almacenamiento;
	const FabricaEmpleado& fabrica;
	const ControladorDepartamentos& departamentos;
	Lista<Empleado> empleados;
	
	void validarAsignacion(
						   const std::string& idDepartamento,
						   const std::string& codigoPuesto) const;
	
public:
	ControladorEmpleados(
						 IAlmacenamientoEmpleados& almacenamiento,
						 const FabricaEmpleado& fabrica,
						 const ControladorDepartamentos& departamentos);
	
	ControladorEmpleados(const ControladorEmpleados&) = delete;
	ControladorEmpleados& operator=(const ControladorEmpleados&) = delete;
	
	Empleado* registrar(const DatosEmpleado& datos);
	
	Empleado* buscar(const std::string& identificacion) const;
	
	void eliminar(const std::string& identificacion);
	
	void asignarPuesto(
					   const std::string& identificacion,
					   const std::string& idDepartamento,
					   const std::string& codigoPuesto);
	
	void desasignarDepartamento(const std::string& idDepartamento);
	void desasignarPuesto(
						  const std::string& idDepartamento,
						  const std::string& codigoPuesto);
	
	int contarPorDepartamento(const std::string& idDepartamento) const;
	
	const Lista<Empleado>& getEmpleados() const;
	
	void guardar() const;
};

#endif
